package com.app.dineEaseAdmin.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.app.dineEaseAdmin.databinding.ActivityLoginBinding
import com.app.dineEaseAdmin.model.AdminTokenModel
import com.app.dineEaseAdmin.model.LoginModel
import com.app.dineEaseAdmin.utils.Constants
import com.app.dineEaseAdmin.utils.Utils
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.messaging.FirebaseMessaging

// admin login
class LoginActivity : AppCompatActivity() {
    private val binding by lazy { ActivityLoginBinding.inflate(layoutInflater) }
    private lateinit var database: FirebaseDatabase
    private var login = LoginModel()
    private var isLogin: Boolean? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        enableEdgeToEdge()

        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom)
            insets
        }

        database = FirebaseDatabase.getInstance()

        checkLoginRegister()

        binding.apply {

            btLogin.setOnClickListener {
                if (binding.btLogin.text.toString() == "Add New") {
                    checkRegisterInput()
                } else if (login.email == binding.etEmail.text.toString() && login.password == binding.etPassword.text.toString()) {
                    FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
                        if (!task.isSuccessful) {
                            return@OnCompleteListener
                        }
                        val token = task.result
                        saveToken(token)
                        val sharedPreferences= getSharedPreferences("LOGIN_REF", MODE_PRIVATE)
                        val editor = sharedPreferences.edit()
                        editor.putBoolean("LOGIN_REF", true)
                        editor.apply()
                        startActivity(Intent(this@LoginActivity, HomeMainActivity::class.java))
                        finish()

                    })

                } else {
                    Toast.makeText(this@LoginActivity, "Something went wrong", Toast.LENGTH_SHORT).show()
                }
            }
        }

    }
//checking inputs
    private fun checkRegisterInput() {
        if (binding.etEmail.text.toString().isEmpty()) {
            binding.etEmail.error = "Empty"
        } else if (binding.etPassword.text.toString().isEmpty()) {
            binding.etPassword.error = "Empty"
        } else {
            createLogin()
        }
    }

    //check is already admin id created or not
    private fun checkLoginRegister() {

        database.reference.child("LOGIN_REF").addValueEventListener(object :
            ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                if (dataSnapshot.exists()) {
                    login = dataSnapshot.getValue(LoginModel::class.java)!!
                    Log.d("checklogins", "onDataChange: $login")

                } else {
                    binding.btLogin.text = "Add New"
                    Toast.makeText(
                        this@LoginActivity, "Please Register to Login", Toast.LENGTH_SHORT).show()

                }
            }

            override fun onCancelled(databaseError: DatabaseError) {

                Toast.makeText(this@LoginActivity, "Something went wrong", Toast.LENGTH_SHORT)
                    .show()

            }
        })
    }



    //creating login of admin
    private fun createLogin() {


        val login = LoginModel(
            "LOGIN_REF",
            binding.etEmail.text.toString(),
            binding.etPassword.text.toString()
        )

        database.reference.child("LOGIN_REF").setValue(login)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {

                    binding.btLogin.text = "Login"

                    checkLoginRegister()
                    Utils.showMessage(this@LoginActivity, "Login Registered")

                } else {

                    Utils.showMessage(this@LoginActivity, "Something went wrong")

                }
            }


    }


    private fun saveToken(token: String) {
        val reference = database.getReference(Constants.ADMIN_TOKEN_REF)
        val data = AdminTokenModel("tokenId", token)

        reference.child("tokenId").setValue(data)
            .addOnSuccessListener {
                println("admin token saved")
            }
            .addOnFailureListener { exception ->
                println("admin token failed")
            }
    }

}