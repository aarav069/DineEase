package com.app.dineEaseAdmin.activities

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import com.app.dineEaseAdmin.R
import com.app.dineEaseAdmin.databinding.ActivitySplashBinding
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {
    private val binding by lazy { ActivitySplashBinding.inflate(layoutInflater) }
    private var currentIndex = 0
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var textView: TextView
    private val textToAnimate = "A Perfect Restaurant App"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        enableEdgeToEdge()

        val sharedPreferences = getSharedPreferences("LOGIN_REF", MODE_PRIVATE)
        val isLogin = sharedPreferences.getBoolean("LOGIN_REF", false)

        //checking admin login and take next activity
        if(isLogin) {
            Handler(Looper.getMainLooper()).postDelayed({
                val intent = Intent(this, HomeMainActivity::class.java)
                startActivity(intent)
                finish()
            },2500)
        } else {
            Handler(Looper.getMainLooper()).postDelayed({
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish()
            },2500)
        }

        textView = binding.textView

        animateText()

    }

    //animation of tagling
    private fun animateText() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (currentIndex < textToAnimate.length) {
                    textView.append(textToAnimate[currentIndex].toString())
                    currentIndex++
                    handler.postDelayed(this, 70)
                }
            }
        }, 70)
    }


}