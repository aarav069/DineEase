package com.app.dineEaseAdmin.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import com.app.dineEaseAdmin.databinding.ActivityWelcomeBinding
//intro screen
class WelcomeActivity : AppCompatActivity() {
    private val binding by lazy { ActivityWelcomeBinding.inflate(layoutInflater) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        enableEdgeToEdge()

       binding.btStart.setOnClickListener {
           startActivity(Intent(this@WelcomeActivity, AuthActivity::class.java))
           finish()
       }

    }
}