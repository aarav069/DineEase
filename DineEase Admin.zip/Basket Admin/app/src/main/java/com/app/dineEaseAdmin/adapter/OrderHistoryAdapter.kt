package com.app.dineEaseAdmin.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.app.dineEaseAdmin.databinding.ItemOrderHistoryBinding
import com.app.dineEaseAdmin.model.OrderModel

//setting order list to recycler view
class OrderHistoryAdapter(private val setData: SetOrderData) : ListAdapter<OrderModel, OrderHistoryAdapter.OrderVH>(
    DiffUtils
) {
    inner class OrderVH(val binding: ItemOrderHistoryBinding) : RecyclerView.ViewHolder(binding.root)

    object DiffUtils : DiffUtil.ItemCallback<OrderModel>() {
        override fun areItemsTheSame(oldItem: OrderModel, newItem: OrderModel): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: OrderModel, newItem: OrderModel): Boolean {
            return oldItem == newItem
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderVH {
        val binding = ItemOrderHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return OrderVH(binding)
    }

    override fun onBindViewHolder(holder: OrderVH, position: Int) {
        val item = getItem(position)

        holder.binding.apply {

//setting data from list to view
            setData.setOrderData(holder, item)

        }



    }



    interface SetOrderData {
        fun setOrderData(holder: OrderVH, orderModel: OrderModel)
    }


}







