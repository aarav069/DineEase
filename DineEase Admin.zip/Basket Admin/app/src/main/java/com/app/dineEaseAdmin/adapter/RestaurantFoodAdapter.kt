package com.app.dineEaseAdmin.adapter

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.Navigation
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.app.dineEaseAdmin.R
import com.app.dineEaseAdmin.databinding.ItemFoodBinding
import com.app.dineEaseAdmin.databinding.ItemRestaurantBinding
import com.app.dineEaseAdmin.fragments.AddFoodRestaurantFragmentDirections
import com.app.dineEaseAdmin.fragments.AddRestaurantFragmentDirections
import com.app.dineEaseAdmin.model.FoodModel

//setting restaurant food list to recycler view
class RestaurantFoodAdapter(private val onClick: OnItemClickListener, val id: String) : ListAdapter<FoodModel, RestaurantFoodAdapter.CategoryVH>(DiffUtils) {
    inner class CategoryVH(val binding: ItemFoodBinding) : RecyclerView.ViewHolder(binding.root)

    object DiffUtils : DiffUtil.ItemCallback<FoodModel>() {
        override fun areItemsTheSame(oldItem: FoodModel, newItem: FoodModel): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: FoodModel, newItem: FoodModel): Boolean {
            return oldItem == newItem
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryVH {
        val binding = ItemFoodBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CategoryVH(binding)
    }

    override fun onBindViewHolder(holder: CategoryVH, position: Int) {
        val item = getItem(position)

        holder.binding.apply {
//setting data from list to view
            ivImage.load(item.image) {
                placeholder(R.drawable.placeholder)
                error(R.drawable.placeholder)
            }

            tvOriginalPrice.paintFlags = tvOriginalPrice.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            tvTitle.text = item.name
            tvDescription.text = item.description
            tvRating.text = "${item.rating} Rating"
            tvPrice.text = "₹${item.offerPrice}"
            tvOriginalPrice.text = "₹${item.originalPrice}"

            btDelete.setOnClickListener {
                onClick.onItemDelete(item)
            }

            btEdit.setOnClickListener {
                val action = AddFoodRestaurantFragmentDirections.actionAddFoodRestaurantFragmentToEditFoodRestaurantFragment(item, id)
                Navigation.findNavController(it).navigate(action)
            }

            holder.itemView.setOnClickListener {
                val action = AddFoodRestaurantFragmentDirections.actionAddFoodRestaurantFragmentToEditFoodRestaurantFragment(item, id)
                Navigation.findNavController(it).navigate(action)
            }


        }

    }



    interface OnItemClickListener {
        fun onItemDelete(model: FoodModel)

    }

}







