package com.app.dineEaseAdmin.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.Navigation
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.app.dineEaseAdmin.R
import com.app.dineEaseAdmin.databinding.ItemRestaurantBinding
import com.app.dineEaseAdmin.databinding.ItemRestaurantListBinding
import com.app.dineEaseAdmin.fragments.AddRestaurantFragmentDirections
import com.app.dineEaseAdmin.fragments.RestaurantListFragmentDirections
import com.app.dineEaseAdmin.model.RestaurantModel


//setting restaurant list to recycler view
class RestaurantOrdersAdapter(private val onClick: OnItemClickListener) : ListAdapter<RestaurantModel, RestaurantOrdersAdapter.CategoryVH>(DiffUtils) {
    inner class CategoryVH(val binding: ItemRestaurantListBinding) : RecyclerView.ViewHolder(binding.root)

    object DiffUtils : DiffUtil.ItemCallback<RestaurantModel>() {
        override fun areItemsTheSame(oldItem: RestaurantModel, newItem: RestaurantModel): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: RestaurantModel, newItem: RestaurantModel): Boolean {
            return oldItem == newItem
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryVH {
        val binding = ItemRestaurantListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CategoryVH(binding)
    }

    override fun onBindViewHolder(holder: CategoryVH, position: Int) {
        val item = getItem(position)

        holder.binding.apply {
//setting data from list to view
            image.load(item.image) {
                placeholder(R.drawable.placeholder)
                error(R.drawable.placeholder)
            }

            tvTitle.text = item.restaurantName
            tvRating.text = "${item.rating} Rating"
            tvPrice.text = "₹${item.reservationCharges}"




            holder.itemView.setOnClickListener {
                val action = RestaurantListFragmentDirections.actionOrdersListFragmentToOrdersFragment(item)
                Navigation.findNavController(it).navigate(action)
            }


        }

    }



    interface OnItemClickListener {
        fun onItemClick(model: RestaurantModel)

    }

}







