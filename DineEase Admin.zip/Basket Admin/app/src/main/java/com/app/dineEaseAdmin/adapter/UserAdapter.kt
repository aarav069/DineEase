package com.app.dineEaseAdmin.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.Navigation
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.app.dineEaseAdmin.R
import com.app.dineEaseAdmin.databinding.ItemUserBinding
import com.app.dineEaseAdmin.fragments.UsersListFragmentDirections
import com.app.dineEaseAdmin.model.UserModel

//setting user list to recycler view
class UserAdapter : ListAdapter<UserModel, UserAdapter.CategoryVH>(DiffUtils) {
    inner class CategoryVH(val binding: ItemUserBinding) : RecyclerView.ViewHolder(binding.root)

    object DiffUtils : DiffUtil.ItemCallback<UserModel>() {
        override fun areItemsTheSame(oldItem: UserModel, newItem: UserModel): Boolean {
            return oldItem.userId == newItem.userId
        }

        override fun areContentsTheSame(oldItem: UserModel, newItem: UserModel): Boolean {
            return oldItem == newItem
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryVH {
        val binding = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CategoryVH(binding)
    }

    override fun onBindViewHolder(holder: CategoryVH, position: Int) {
        val item = getItem(position)

        holder.binding.apply {
//setting data from list to view
            tvName.text = item.name
            tvPhoneNumber.text = item.phoneNumber
            tvCity.text = "${item.city}"

            holder.itemView.setOnClickListener {
                val action = UsersListFragmentDirections.actionUsersListFragmentToUserDetailsFragment(item)
                Navigation.findNavController(it).navigate(action)
            }


        }

    }





}







