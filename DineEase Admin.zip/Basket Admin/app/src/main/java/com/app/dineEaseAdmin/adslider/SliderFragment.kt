package com.app.dineEaseAdmin.adslider

import android.app.Activity
import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.app.dineEaseAdmin.R
import com.app.dineEaseAdmin.databinding.DialogDeleteBinding
import com.app.dineEaseAdmin.databinding.FragmentSliderBinding
import com.app.dineEaseAdmin.utils.Constants
import com.app.dineEaseAdmin.utils.Utils
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.FirebaseStorage
import java.util.UUID

//managing sliders
class SliderFragment : Fragment(), SliderAdapter.OnItemClickListener {
    private val binding by lazy { FragmentSliderBinding.inflate(layoutInflater) }
    private lateinit var database: FirebaseDatabase
    private lateinit var dbStorage: FirebaseStorage
    private lateinit var progress: AlertDialog
    private lateinit var sliderList: ArrayList<SliderModel>
    private var sliderImageUri: Uri? = null
    private lateinit var adapter: SliderAdapter
    private lateinit var deleteDialog: AlertDialog

//picking image from gallery
    private val startForProfileImageResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val resultCode = result.resultCode
            val data = result.data

            when (resultCode) {
                Activity.RESULT_OK -> {
                    sliderImageUri = data?.data!!
                    binding.ivSliderImage.setImageURI(sliderImageUri)

                }

                ImagePicker.RESULT_ERROR -> {
                    Toast.makeText(requireContext(), ImagePicker.getError(data), Toast.LENGTH_SHORT)
                        .show()
                }

                else -> {
                    Toast.makeText(requireContext(), "Task Cancelled", Toast.LENGTH_SHORT).show()
                }
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        database = FirebaseDatabase.getInstance()
        dbStorage = FirebaseStorage.getInstance()
        progress = Utils.showLoading(requireContext())
        sliderList = ArrayList()
        deleteDialog = AlertDialog.Builder(requireContext(), R.style.CustomAlertDialog).create()



        binding.apply {

            sliderRv.layoutManager = LinearLayoutManager(requireContext())
            adapter = SliderAdapter(requireContext(), this@SliderFragment)

            ivSliderImage.setOnClickListener {
                ImagePicker.with(this@SliderFragment)
                    .crop()
                    .createIntent { intent ->
                        startForProfileImageResult.launch(intent)
                    }
            }



            btCreateSlider.setOnClickListener {
                validateSlider()
            }

        }

        fetchSliderData()

    }

    private fun showToast(msg: String) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
    }

    private fun validateSlider() {
        binding.apply {
            if(sliderImageUri == null) {
                showToast("Please select Image")
            }  else {
                uploadSliderImage(sliderImageUri, etLaunchUrl.text.toString())
            }
        }
    }

    //uploading image
    private fun uploadSliderImage(sliderImage: Uri?, url: String) {
        progress.show()
        val fileName = "${UUID.randomUUID()}.jpg"
        dbStorage.reference.child("${Constants.IMAGES}$fileName").putFile(sliderImage!!)
            .addOnSuccessListener {
                it.storage.downloadUrl.addOnSuccessListener { imgUrl ->
                    createSlider(url, imgUrl.toString())
                }
            }
            .addOnFailureListener {
                progress.dismiss()
                showToast("Something went wrong")
            }

    }

    //creating slider
    private fun createSlider(link: String, sliderImgUrl: String) {
        val reference = database.getReference(Constants.SLIDER_DOCUMENT)
        val sliderId = reference.push().key
        val timestamp = System.currentTimeMillis()

        val slider = SliderModel(sliderId!!, sliderImgUrl, link, timestamp)
        reference.child(sliderId).setValue(slider).addOnSuccessListener {
            binding.etLaunchUrl.text = null
            sliderImageUri = null
            binding.ivSliderImage.setImageResource(R.drawable.placeholder)
            progress.dismiss()
            showToast("Slider created successfully")
        }.addOnFailureListener {
            showToast("Something went wrong")
        }


    }

    //fetching slider list
    private fun fetchSliderData() {
        progress.show()
        database.getReference(Constants.SLIDER_DOCUMENT).orderByChild("timestamp").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                sliderList.clear()
                for (childSnapshot in dataSnapshot.children.reversed()) {
                    val sliders = childSnapshot.getValue(SliderModel::class.java)
                    if (sliders != null) {
                        sliderList.add(sliders)
                    }
                }

                if(sliderList.isNotEmpty()) {
                    adapter.submitList(sliderList)
                    binding.tvSliderStatus.visibility = View.GONE
                    binding.sliderRv.visibility = View.VISIBLE
                    binding.sliderRv.adapter = adapter
                } else {
                    val status = "No Slider Created yet"
                    binding.tvSliderStatus.visibility = View.VISIBLE
                    binding.sliderRv.visibility = View.GONE
                    binding.tvSliderStatus.text = status
                }

                progress.dismiss()


            }

            override fun onCancelled(databaseError: DatabaseError) {
                showToast("Something went wrong")
            }
        })
    }

    //show dialog for deleting slider
    private fun showDeleteDialog(slider: SliderModel) {
        deleteDialog = AlertDialog.Builder(requireContext(), R.style.CustomAlertDialog).create()
        val deleteLayout = DialogDeleteBinding.inflate(layoutInflater)
        deleteDialog.setView(deleteLayout.root)
        deleteDialog.setCanceledOnTouchOutside(true)

        deleteLayout.btCancel.setOnClickListener {
            deleteDialog.dismiss()
        }

        deleteLayout.btDelete.setOnClickListener {
            deleteSliderData(slider.sliderId)
        }

        deleteDialog.show()

    }

    //deleting slider
    private fun deleteSliderData(childKey: String) {
        deleteDialog.dismiss()
        progress.show()
        val sliderReference = database.getReference(Constants.SLIDER_DOCUMENT).child(childKey)

        sliderReference.removeValue()
            .addOnSuccessListener {
                showToast("Slider deleted successfully")
            }
            .addOnFailureListener {
                showToast("Something went wrong")
            }
            .addOnCompleteListener {
                progress.dismiss()
            }
    }


    override fun onItemClick(sliderModel: SliderModel) {
        showDeleteDialog(sliderModel)
    }

}