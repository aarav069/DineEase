package com.app.dineEaseAdmin.fragments

import android.app.Activity
import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import coil.load
import com.app.dineEaseAdmin.R
import com.app.dineEaseAdmin.adapter.RestaurantFoodAdapter
import com.app.dineEaseAdmin.databinding.FragmentAddFoodBinding
import com.app.dineEaseAdmin.factory.MainViewModelFactory
import com.app.dineEaseAdmin.model.FoodModel
import com.app.dineEaseAdmin.repository.MainRepository
import com.app.dineEaseAdmin.utils.Constants
import com.app.dineEaseAdmin.utils.Utils
import com.app.dineEaseAdmin.viewmodel.MainViewModel
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.firebase.storage.FirebaseStorage
import java.util.UUID
//creating food of restaurant
class AddFoodRestaurantFragment : Fragment(), RestaurantFoodAdapter.OnItemClickListener {
    private val binding by lazy { FragmentAddFoodBinding.inflate(layoutInflater) }
    private val restaurant: AddFoodRestaurantFragmentArgs by navArgs()
    private lateinit var progress: AlertDialog
    private lateinit var mainViewModel: MainViewModel
    private lateinit var adapter: RestaurantFoodAdapter
    private lateinit var storage: FirebaseStorage
    private  var imageUri: Uri? = null

    //getting image from gallery
    private val startForImageResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val resultCode = result.resultCode
            val data = result.data

            when (resultCode) {
                Activity.RESULT_OK -> {
                    imageUri = data?.data!!
                    binding.ivFoodImage.setImageURI(imageUri)
                }

                ImagePicker.RESULT_ERROR -> {
                    Toast.makeText(requireContext(), ImagePicker.getError(data), Toast.LENGTH_SHORT)
                        .show()
                }

                else -> {
                    Toast.makeText(requireContext(), "Task Cancelled", Toast.LENGTH_SHORT).show()
                }
            }
        }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        storage = FirebaseStorage.getInstance()
        progress = Utils.showLoading(requireContext())
        val repository = MainRepository()
        val factory = MainViewModelFactory(repository)
        mainViewModel = ViewModelProvider(this@AddFoodRestaurantFragment, factory) [MainViewModel::class.java]
        adapter = RestaurantFoodAdapter(this@AddFoodRestaurantFragment, restaurant.restaurantData.id)

        mainViewModel.getRestaurantFood(restaurant.restaurantData.id)

        binding.apply {

            ivImage.load(restaurant.restaurantData.image) {
                placeholder(R.drawable.placeholder)
                error(R.drawable.placeholder)
            }

            tvPrice.text = "₹${restaurant.restaurantData.reservationCharges} Resarvation Charge"
            tvName.text = restaurant.restaurantData.restaurantName
            tvRating.text = restaurant.restaurantData.rating + " Ratings"


            mainViewModel.status.observe(viewLifecycleOwner) {
                if(it) {
                    clearData()
                    progress.dismiss()
                } else {
                    progress.dismiss()
                }
            }


            mainViewModel.restaurantFoodList.observe(viewLifecycleOwner) { list ->
                if(list.isNotEmpty()) {
                    rv.adapter = adapter
                    adapter.submitList(list)
                } else {
                    rv.adapter = adapter
                    adapter.submitList(emptyList())
                    Utils.showMessage(requireContext(), "No Food Found")
                }

            }


            ivFoodImage.setOnClickListener {
                ImagePicker.with(this@AddFoodRestaurantFragment)
                    .crop()
                    .createIntent { intent ->
                        startForImageResult.launch(intent)
                    }
            }

            btAdd.setOnClickListener {
                checkFoodInputs()
            }


        }

        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {
                findNavController().navigateUp()
            }

        })


    }

    //clearing data after successfully adding food
    private fun clearData() {
        binding.apply {
            ivFoodImage.setImageResource(R.drawable.placeholder)
            imageUri = null
            etName.text = null
            etDescription.text = null
            etRating.text = null
            etOfferPrice.text = null
            etOriginalPrice.text = null
        }
    }

    //checking restaurant inputs
    private fun checkFoodInputs() {
        binding.apply {
            val msg = "Empty"
            if(etName.text.toString().isEmpty()) {
                etName.requestFocus()
                etName.error = msg
            } else if(etDescription.text.toString().isEmpty()) {
                etDescription.requestFocus()
                etDescription.error = msg
            } else if(etOfferPrice.text.toString().isEmpty()) {
                etOfferPrice.requestFocus()
                etOfferPrice.error = msg
            } else if(etRating.text.toString().isEmpty()) {
                etRating.requestFocus()
                etRating.error = msg
            } else if(etOriginalPrice.text.toString().isEmpty()) {
                etOriginalPrice.requestFocus()
                etOriginalPrice.error = msg
            } else if(imageUri == null) {
                Utils.showMessage(requireContext(), "Add Image")
            }  else {
                progress.show()
                uploadImage(imageUri)
            }

        }
    }

    //upload image to firebase storage
    private fun uploadImage(imageUri: Uri?) {
        val fileName = UUID.randomUUID().toString() + ".jpg"
        if(imageUri != null) {
            storage.getReference(Constants.IMAGES + fileName).putFile(imageUri)
                .addOnSuccessListener {
                    it.storage.downloadUrl.addOnSuccessListener {imgUrl ->
                        createRestaurantFood(imgUrl.toString())
                    }
                }.addOnFailureListener {
                    progress.dismiss()
                    Utils.showMessage(requireContext(), "Image Upload Failed")
                }
        }
    }

    //creating restaurant food
    private fun createRestaurantFood(image: String) {
        mainViewModel.createRestaurantFood(
            restaurant.restaurantData.id,
            image,
            binding.etName.text.toString(),
            binding.etOriginalPrice.text.toString(),
            binding.etOfferPrice.text.toString(),
            binding.etDescription.text.toString(),
            binding.etRating.text.toString()
        )
    }

    //deleting restaurant food
    override fun onItemDelete(model: FoodModel) {
        progress.show()
        mainViewModel.deleteRestaurantFood(restaurant.restaurantData.id, model.id)
    }

}