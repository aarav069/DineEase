package com.app.dineEaseAdmin.fragments

import android.app.Activity
import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.findViewTreeViewModelStoreOwner
import androidx.navigation.fragment.findNavController
import com.app.dineEaseAdmin.R
import com.app.dineEaseAdmin.adapter.RestaurantAdapter
import com.app.dineEaseAdmin.databinding.FragmentAddRestaurantBinding
import com.app.dineEaseAdmin.factory.MainViewModelFactory
import com.app.dineEaseAdmin.model.RestaurantModel
import com.app.dineEaseAdmin.repository.MainRepository
import com.app.dineEaseAdmin.utils.Constants
import com.app.dineEaseAdmin.utils.Utils
import com.app.dineEaseAdmin.viewmodel.MainViewModel
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.firebase.storage.FirebaseStorage
import java.util.UUID
//creating restaurant
class AddRestaurantFragment : Fragment(), RestaurantAdapter.OnItemClickListener {
    private val binding by lazy { FragmentAddRestaurantBinding.inflate(layoutInflater) }
    private lateinit var mainViewModel: MainViewModel
    private lateinit var adapter: RestaurantAdapter
    private  var image: Uri? = null
    private lateinit var storage: FirebaseStorage
    private lateinit var progress: AlertDialog

    //getting image from gallery
    private val startForImageResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val resultCode = result.resultCode
            val data = result.data

            when (resultCode) {
                Activity.RESULT_OK -> {
                    image = data?.data!!
                    binding.ivServiceImage.setImageURI(image)
                }

                ImagePicker.RESULT_ERROR -> {
                    Toast.makeText(requireContext(), ImagePicker.getError(data), Toast.LENGTH_SHORT)
                        .show()
                }

                else -> {
                    Toast.makeText(requireContext(), "Task Cancelled", Toast.LENGTH_SHORT).show()
                }
            }
        }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        storage = FirebaseStorage.getInstance()
        progress = Utils.showLoading(requireContext())
        val repository = MainRepository()
        val factory = MainViewModelFactory(repository)
        mainViewModel = ViewModelProvider(this@AddRestaurantFragment, factory) [MainViewModel::class.java]
        adapter = RestaurantAdapter(this@AddRestaurantFragment)

        

        binding.apply {

            mainViewModel.status.observe(viewLifecycleOwner) {
                if(it) {
                    clearData()
                    progress.dismiss()
                } else {
                    progress.dismiss()
                }
            }

//fetching restaurant from firebase
            mainViewModel.restaurantList.observe(viewLifecycleOwner) { list ->
                if(list.isNotEmpty()) {
                    rv.adapter = adapter
                    adapter.submitList(list)
                } else {
                    rv.adapter = adapter
                    adapter.submitList(emptyList())
                    Utils.showMessage(requireContext(), "No Restaurants Found")
                }

            }


            ivServiceImage.setOnClickListener {
                ImagePicker.with(this@AddRestaurantFragment)
                    .crop()
                    .createIntent { intent ->
                        startForImageResult.launch(intent)
                    }
            }

            btAddRestaurant.setOnClickListener {
                checkServiceInputs()
            }


        }

        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {
                findNavController().navigateUp()
            }

        })


    }

    //clearing data after successfully creating restaurant
    private fun clearData() {
        binding.apply {
            ivServiceImage.setImageResource(R.drawable.placeholder)
            image = null
            etName.text = null
            etLocation.text = null
            etRating.text = null
            etCharges.text = null
        }
    }

    //checking restaurant inputs
    private fun checkServiceInputs() {
        binding.apply {
            val msg = "Empty"
            if(etName.text.toString().isEmpty()) {
                etName.requestFocus()
                etName.error = msg
            } else if(etCharges.text.toString().isEmpty()) {
                etCharges.requestFocus()
                etCharges.error = msg
            } else if(etLocation.text.toString().isEmpty()) {
                etLocation.requestFocus()
                etLocation.error = msg
            } else if(etRating.text.toString().isEmpty()) {
                etRating.requestFocus()
                etRating.error = msg
            } else if(image == null) {
                Utils.showMessage(requireContext(), "Add Image")
            }  else {
                progress.show()
                uploadImage(image)
            }

        }
    }

    //upload image to firebase storage
    private fun uploadImage(imageUri: Uri?) {
        val fileName = UUID.randomUUID().toString() + ".jpg"
        if(imageUri != null) {
            storage.getReference(Constants.IMAGES + fileName).putFile(imageUri)
                .addOnSuccessListener {
                    it.storage.downloadUrl.addOnSuccessListener {imgUrl ->
                        createRestaurant(imgUrl.toString())
                    }
                }.addOnFailureListener {
                    progress.dismiss()
                    Utils.showMessage(requireContext(), "Image Upload Failed")
                }
        }
    }

    //creating restaurant
    private fun createRestaurant(image: String) {
        mainViewModel.createRestaurant(
            image,
            binding.etName.text.toString(),
            binding.etRating.text.toString(),
            binding.etLocation.text.toString(),
            binding.etCharges.text.toString(),
        )
    }

    //deleting restaurant
    override fun onItemDelete(model: RestaurantModel) {
        progress.show()
        mainViewModel.deleteRestaurant(model.id)
    }

}