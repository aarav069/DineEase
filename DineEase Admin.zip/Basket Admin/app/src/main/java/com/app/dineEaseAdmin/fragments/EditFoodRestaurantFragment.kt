package com.app.dineEaseAdmin.fragments

import android.app.Activity
import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import coil.load
import com.app.dineEaseAdmin.R
import com.app.dineEaseAdmin.databinding.FragmentEditRestaurantFoodBinding
import com.app.dineEaseAdmin.factory.MainViewModelFactory
import com.app.dineEaseAdmin.model.FoodModel
import com.app.dineEaseAdmin.repository.MainRepository
import com.app.dineEaseAdmin.utils.Constants
import com.app.dineEaseAdmin.utils.Utils
import com.app.dineEaseAdmin.viewmodel.MainViewModel
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.firebase.storage.FirebaseStorage
import java.util.UUID

//editing of restaurant food
class EditFoodRestaurantFragment : Fragment() {
    private val binding by lazy { FragmentEditRestaurantFoodBinding.inflate(layoutInflater) }
    private var imageUri: Uri? = null
    private val data: EditFoodRestaurantFragmentArgs by navArgs()
    private lateinit var progress: AlertDialog
    private lateinit var mainViewModel: MainViewModel
    private lateinit var storage: FirebaseStorage


    //pick image from gallery
    private val startForImageResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val resultCode = result.resultCode
            val data = result.data

            when (resultCode) {
                Activity.RESULT_OK -> {
                    imageUri = data?.data!!
                    binding.image.setImageURI(imageUri)
                }

                ImagePicker.RESULT_ERROR -> {
                    Toast.makeText(requireContext(), ImagePicker.getError(data), Toast.LENGTH_SHORT)
                        .show()
                }

                else -> {
                    Toast.makeText(requireContext(), "Task Cancelled", Toast.LENGTH_SHORT).show()
                }
            }
        }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        progress = Utils.showLoading(requireContext())
        storage = FirebaseStorage.getInstance()
        val repository = MainRepository()
        val factory = MainViewModelFactory(repository)
        mainViewModel = ViewModelProvider(this@EditFoodRestaurantFragment, factory) [MainViewModel::class.java]


        mainViewModel.status.observe(viewLifecycleOwner) {
            if(it) {
                progress.dismiss()
                findNavController().navigateUp()
            } else {
                progress.dismiss()
                Utils.showMessage(requireContext(), "Something went wrong")
            }
        }


        binding.apply {

            image.setOnClickListener {
                ImagePicker.with(this@EditFoodRestaurantFragment)
                    .crop()
                    .createIntent { intent ->
                        startForImageResult.launch(intent)
                    }
            }

            btUpdate.setOnClickListener {
                checkServiceInputs()
            }

            setData(data.food)

        }

        //managing back press
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {
                findNavController().navigateUp()
            }

        })


    }

    private fun checkServiceInputs() {
        binding.apply {
            val msg = "Empty"
            if(etName.text.toString().isEmpty()) {
                etName.requestFocus()
                etName.error = msg
            } else if(etPrice.text.toString().isEmpty()) {
                etPrice.requestFocus()
                etPrice.error = msg
            } else if(etOfferPrice.text.toString().isEmpty()) {
                etOfferPrice.requestFocus()
                etOfferPrice.error = msg
            } else if(etRating.text.toString().isEmpty()) {
                etRating.requestFocus()
                etRating.error = msg
            } else if(etDescription.text.toString().isEmpty()) {
                etDescription.requestFocus()
                etDescription.error = msg
            } else {
                progress.show()
                if(imageUri != null) {
                    uploadImage(imageUri)
                } else {
                    update(null)
                }
            }

        }
    }

    private fun update(image: String?) {
        val image1 = image ?: data.food.image

        mainViewModel.updateRestaurantFood(
            data.id,
            data.food.id,
            image1,
            binding.etName.text.toString(),
            binding.etPrice.text.toString(),
            binding.etOfferPrice.text.toString(),
            binding.etDescription.text.toString(),
            binding.etRating.text.toString(),
            )
    }

    private fun uploadImage(imageUri: Uri?) {
        val fileName = UUID.randomUUID().toString() + ".jpg"
        if(imageUri != null) {
            storage.getReference(Constants.IMAGES + fileName).putFile(imageUri)
                .addOnSuccessListener {
                    it.storage.downloadUrl.addOnSuccessListener {imgUrl ->
                        update(imgUrl.toString())
                    }
                }.addOnFailureListener {
                    progress.dismiss()
                    Utils.showMessage(requireContext(), "Image Upload Failed")
                }
        }
    }



    private fun setData(model: FoodModel) {
        binding.apply {
            image.load(model.image) {
                placeholder(R.drawable.placeholder)
                error(R.drawable.placeholder)
            }

            etName.setText(model.name)
            etPrice.setText(model.originalPrice)
            etOfferPrice.setText(model.offerPrice)
            etDescription.setText(model.description)
            etRating.setText(model.rating)

        }
    }

}