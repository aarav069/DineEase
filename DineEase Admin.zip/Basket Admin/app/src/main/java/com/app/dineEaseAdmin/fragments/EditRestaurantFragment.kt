package com.app.dineEaseAdmin.fragments

import android.app.Activity
import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import coil.load
import com.app.dineEaseAdmin.R
import com.app.dineEaseAdmin.databinding.FragmentEditRestaurantBinding
import com.app.dineEaseAdmin.factory.MainViewModelFactory
import com.app.dineEaseAdmin.model.RestaurantModel
import com.app.dineEaseAdmin.repository.MainRepository
import com.app.dineEaseAdmin.utils.Constants
import com.app.dineEaseAdmin.utils.Utils
import com.app.dineEaseAdmin.viewmodel.MainViewModel
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.firebase.storage.FirebaseStorage
import java.util.UUID

//editing restaurant
class EditRestaurantFragment : Fragment() {
    private val binding by lazy { FragmentEditRestaurantBinding.inflate(layoutInflater) }
    private var imageUri: Uri? = null
    private val restaurant: EditRestaurantFragmentArgs by navArgs()
    private lateinit var progress: AlertDialog
    private lateinit var mainViewModel: MainViewModel
    private lateinit var storage: FirebaseStorage


    //getting image from gallery
    private val startForImageResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val resultCode = result.resultCode
            val data = result.data

            when (resultCode) {
                Activity.RESULT_OK -> {
                    imageUri = data?.data!!
                    binding.image.setImageURI(imageUri)
                }

                ImagePicker.RESULT_ERROR -> {
                    Toast.makeText(requireContext(), ImagePicker.getError(data), Toast.LENGTH_SHORT)
                        .show()
                }

                else -> {
                    Toast.makeText(requireContext(), "Task Cancelled", Toast.LENGTH_SHORT).show()
                }
            }
        }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        progress = Utils.showLoading(requireContext())
        storage = FirebaseStorage.getInstance()
        val repository = MainRepository()
        val factory = MainViewModelFactory(repository)
        mainViewModel = ViewModelProvider(this@EditRestaurantFragment, factory) [MainViewModel::class.java]


        mainViewModel.status.observe(viewLifecycleOwner) {
            if(it) {
                progress.dismiss()
                findNavController().navigate(R.id.action_editServiceFragment_to_addServiceFragment)
            } else {
                progress.dismiss()
                Utils.showMessage(requireContext(), "Something went wrong")
            }
        }


        binding.apply {

            image.setOnClickListener {
                ImagePicker.with(this@EditRestaurantFragment)
                    .crop()
                    .createIntent { intent ->
                        startForImageResult.launch(intent)
                    }
            }

            btUpdate.setOnClickListener {
                checkRestaurantInputs()
            }

            setData(restaurant.restaurantData)

        }

        //manging back press
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {
                findNavController().navigateUp()
            }

        })


    }

    //checking restaurant inputs
    private fun checkRestaurantInputs() {
        binding.apply {
            val msg = "Empty"
            if(etName.text.toString().isEmpty()) {
                etName.requestFocus()
                etName.error = msg
            } else if(etPrice.text.toString().isEmpty()) {
                etPrice.requestFocus()
                etPrice.error = msg
            } else if(etLocation.text.toString().isEmpty()) {
                etLocation.requestFocus()
                etLocation.error = msg
            } else if(etRating.text.toString().isEmpty()) {
                etRating.requestFocus()
                etRating.error = msg
            } else {
                progress.show()
                if(imageUri != null) {
                    uploadImage(imageUri)
                } else {
                    update(null)
                }
            }

        }
    }

    //updating restaurant data
    private fun update(img: String?) {
        val image = img ?: restaurant.restaurantData.image

        mainViewModel.updateRestaurant(
            restaurant.restaurantData.id,
            image,
            binding.etName.text.toString(),
            binding.etLocation.text.toString(),
            binding.etPrice.text.toString(),
            )
    }

    //uploading image to firebase
    private fun uploadImage(imageUri: Uri?) {
        val fileName = UUID.randomUUID().toString() + ".jpg"
        if(imageUri != null) {
            storage.getReference(Constants.IMAGES + fileName).putFile(imageUri)
                .addOnSuccessListener {
                    it.storage.downloadUrl.addOnSuccessListener {imgUrl ->
                        update(imgUrl.toString())
                    }
                }.addOnFailureListener {
                    progress.dismiss()
                    Utils.showMessage(requireContext(), "Image Upload Failed")
                }
        }
    }



    //setting existing restaurant data to views
    private fun setData(model: RestaurantModel) {
        binding.apply {
            image.load(model.image) {
                placeholder(R.drawable.placeholder)
                error(R.drawable.placeholder)
            }

            etName.setText(model.restaurantName)
            etPrice.setText(model.reservationCharges)
            etLocation.setText(model.location)
            etRating.setText(model.rating)

        }
    }

}