package com.app.dineEaseAdmin.fragments

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import com.app.dineEaseAdmin.R
import com.app.dineEaseAdmin.activities.LoginActivity
import com.app.dineEaseAdmin.databinding.DialogExitBinding
import com.app.dineEaseAdmin.databinding.FragmentHomeBinding
import com.app.dineEaseAdmin.model.AdminTokenModel
import com.app.dineEaseAdmin.model.UserModel
import com.app.dineEaseAdmin.pushnotification.SendNotification
import com.app.dineEaseAdmin.utils.Constants
import com.app.dineEaseAdmin.utils.SharedPref
import com.app.dineEaseAdmin.utils.Utils
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

//home screen
class HomeFragment : Fragment() {
    private val binding by lazy { FragmentHomeBinding.inflate(layoutInflater) }
    private lateinit var bottomSheet: BottomSheetDialog

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        bottomSheet = BottomSheetDialog(requireContext())

        fetchAdminToken()



        binding.apply {

            btMenu.setOnClickListener {
                showExitDialog()
            }

            btAddRestaurant.setOnClickListener {
                Utils.navigate(it, R.id.action_homeFragment_to_addServiceFragment)
            }

            btUsers.setOnClickListener {
                Utils.navigate(it, R.id.action_homeFragment_to_usersListFragment)
            }

            btViewOrders.setOnClickListener {
                Utils.navigate(it, R.id.action_homeFragment_to_ordersListFragment)
            }



            btSlider.setOnClickListener {
                Utils.navigate(it, R.id.action_homeFragment_to_sliderFragment)
            }

            btLogin.setOnClickListener {
                Utils.navigate(it, R.id.action_homeFragment_to_manageLoginFragment)
            }

            btLogout.setOnClickListener {
                SharedPref.clearData(requireContext())
                Utils.showMessage(requireContext(), "Logout Successfully")
                startActivity(Intent(requireActivity(), LoginActivity::class.java))
                requireActivity().finish()
            }

        }

        //managing back press
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {
                if(bottomSheet.isShowing) {
                    bottomSheet.dismiss()
                } else {
                    showExitDialog()
                }
            }

        })

    }

    private fun fetchAdminToken() {
        val reference = Firebase.database.getReference(Constants.ADMIN_TOKEN_REF)
        reference.child("tokenId").get().addOnSuccessListener { dataSnapshot ->
            if (dataSnapshot.exists()) {
                val tokenData = dataSnapshot.getValue(AdminTokenModel::class.java)

                tokenData?.let {
                    Constants.ADMIN_TOKEN = tokenData
                    Log.d("mmm", "fetchAdminToken: $tokenData")
                    Log.d("mmm", "fetchAdminToken: ${Constants.ADMIN_TOKEN}")
                }
            } else {
                println("Admin token not found")
            }
        }.addOnFailureListener { exception ->
            println("Failed to fetch admin token: ${exception.message}")
        }
    }

    //showing exit dialog
    private fun showExitDialog() {
        val bottomSheet = BottomSheetDialog(requireContext())
        val layout = DialogExitBinding.inflate(layoutInflater)
        bottomSheet.setContentView(layout.root)
        bottomSheet.setCanceledOnTouchOutside(true)
        layout.btExit.setOnClickListener {
            bottomSheet.dismiss()
            requireActivity().finish()
        }
        layout.btCancel.setOnClickListener {
            bottomSheet.dismiss()
        }
        bottomSheet.show()
    }

}