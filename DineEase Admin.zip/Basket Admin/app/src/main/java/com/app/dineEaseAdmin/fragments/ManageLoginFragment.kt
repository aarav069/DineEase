package com.app.dineEaseAdmin.fragments

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.app.dineEaseAdmin.activities.LoginActivity
import com.app.dineEaseAdmin.databinding.FragmentManageLoginBinding
import com.app.dineEaseAdmin.model.LoginModel
import com.app.dineEaseAdmin.utils.SharedPref
import com.app.dineEaseAdmin.utils.Utils
import com.google.firebase.database.FirebaseDatabase

//managing admin data
class ManageLoginFragment : Fragment() {
    private val binding by lazy { FragmentManageLoginBinding.inflate(layoutInflater) }
    private lateinit var progress: AlertDialog
    private lateinit var database: FirebaseDatabase

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        database = FirebaseDatabase.getInstance()
        progress = Utils.showLoading(requireContext())

        binding.apply {


            btLogOut.setOnClickListener {
                SharedPref.clearData(requireContext())
                Utils.showMessage(requireContext(), "Logout Successfully")
                startActivity(Intent(requireActivity(), LoginActivity::class.java))
                requireActivity().finish()
            }

            binding.btSave.setOnClickListener {
                if(binding.etEmail.text.toString().isEmpty()) {
                    binding.etEmail.error = "Empty"
                } else if (binding.etPass1.text.toString().isEmpty()) {
                    binding.etPass1.error = "Empty"
                } else if (binding.etPass2.text.toString().isEmpty()) {
                    binding.etPass2.error = "Empty"
                } else if(binding.etPass1.text.toString() != binding.etPass2.text.toString()) {
                    Utils.showMessage(requireContext(), "Password Not Match")
                } else {
                    createLogin()
                }
            }
        }

        //managing back press
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {
                findNavController().navigateUp()
            }

        })
    }

    //create login
    private fun createLogin() {
        progress.show()

        val login = LoginModel(
            "LOGIN_REF",
            binding.etEmail.text.toString(),
            binding.etPass1.text.toString()
        )

        database.reference.child("LOGIN_REF").setValue(login).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                progress.dismiss()
                Utils.showMessage(requireContext(), "Login Updated")
                findNavController().navigateUp()
            } else {
                progress.dismiss()
                Utils.showMessage(requireContext(), "Something went wrong")
            }
        }
    }

}