package com.app.dineEaseAdmin.fragments

import android.app.AlertDialog
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.navArgs
import coil.load
import com.app.dineEaseAdmin.R
import com.app.dineEaseAdmin.adapter.CartHistoryAdapter
import com.app.dineEaseAdmin.adapter.OrderHistoryAdapter
import com.app.dineEaseAdmin.databinding.DialogOrderStatusBinding
import com.app.dineEaseAdmin.databinding.FragmentOrdersBinding
import com.app.dineEaseAdmin.factory.AuthViewModelFactory
import com.app.dineEaseAdmin.factory.MainViewModelFactory
import com.app.dineEaseAdmin.model.OrderModel
import com.app.dineEaseAdmin.model.RestaurantModel
import com.app.dineEaseAdmin.pushnotification.SendNotification
import com.app.dineEaseAdmin.repository.AuthRepository
import com.app.dineEaseAdmin.repository.MainRepository
import com.app.dineEaseAdmin.utils.Utils
import com.app.dineEaseAdmin.utils.Utils.gone
import com.app.dineEaseAdmin.utils.Utils.visible
import com.app.dineEaseAdmin.viewmodel.AuthViewModel
import com.app.dineEaseAdmin.viewmodel.MainViewModel
import com.google.firebase.auth.FirebaseAuth

//restaurant orders
class OrdersFragment : Fragment(),OrderHistoryAdapter.SetOrderData {
    private val binding by lazy { FragmentOrdersBinding.inflate(layoutInflater) }
    private val restaurant: OrdersFragmentArgs by navArgs()
    private lateinit var mainViewModel: MainViewModel
    private lateinit var authViewModel: AuthViewModel
    private lateinit var adapter: OrderHistoryAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val repository = MainRepository()
        val factory = MainViewModelFactory(repository)
        mainViewModel = ViewModelProvider(this@OrdersFragment, factory) [MainViewModel::class.java]
        adapter = OrderHistoryAdapter(this@OrdersFragment)

        val authRepository = AuthRepository(FirebaseAuth.getInstance(), requireContext())
        val authFactory = AuthViewModelFactory(authRepository)
        authViewModel = ViewModelProvider(requireActivity(), authFactory) [AuthViewModel::class.java]


        binding.apply {


            //fetching restaurant orders by id
            mainViewModel.fetchOrdersByRestaurantId(restaurant.restaurant.id)


            setData(restaurant.restaurant)

            //getting restaurant orders list
            mainViewModel.ordersList.observe(viewLifecycleOwner) { list ->
                if (list.isNotEmpty()) {
                    loadingLayout.gone()
                    mainLayout.visible()
                    rv.adapter = adapter
                    adapter.submitList(list)

                } else {
                    loadingLayout.visible()
                    mainLayout.gone()
                    tvStatus.text = "No Orders Found"
                }
            }


        }

    }

    //set data of restaurant
    private fun setData(restaurant: RestaurantModel) {
        binding.apply {
            ivImage.load(restaurant.image) {
                placeholder(R.drawable.placeholder)
                error(R.drawable.placeholder)
            }

            tvName.text = restaurant.restaurantName
            tvRating.text = "${restaurant.rating} Ratings"
            tvAmount.text = "₹${restaurant.reservationCharges}"
            tvId.text = restaurant.id
            tvLocation.text = "${restaurant.location}"

        }
    }


//showing status update dailog
    private fun showUpdateDialog(order: OrderModel) {
        val dialog = AlertDialog.Builder(requireContext(), R.style.CustomAlertDialog).create()
        val layout = DialogOrderStatusBinding.inflate(layoutInflater)
        dialog.setView(layout.root)

        layout.apply {

            btClose.setOnClickListener {
                dialog.dismiss()
            }

            rGroup.setOnCheckedChangeListener { _, checkedId ->
                val selectedRadioButton: RadioButton = root.findViewById(checkedId)
                val orderUpdate = selectedRadioButton.text.toString()

                btUpdateStatus.setOnClickListener {

                    mainViewModel.updateOrderStatus(order.userId, order.id, orderUpdate)
                    SendNotification.pushNotification(order.userToken, "Order Updated", "Your Order Status: $orderUpdate", requireContext())
                    Utils.showMessage(requireContext(), "Order Status Updated")
                    dialog.dismiss()
                }

            }

        }

        dialog.show()
    }

    //setting orders data to rv
    override fun setOrderData(holder: OrderHistoryAdapter.OrderVH, orderModel: OrderModel) {
        holder.binding.apply {

            authViewModel.fetchUserData(orderModel.userId)
            authViewModel.user.observe(viewLifecycleOwner) { user ->

                tvTitle.text = user.name
                tvTime.text = user.city

                btCall.setOnClickListener {
                    Utils.openDialer(requireContext(), user.phoneNumber)
                }

            }

            tvStatus.setOnClickListener {
                showUpdateDialog(orderModel)
            }


            tvMembers.text =  "${orderModel.members} Members"
            tvDate.text = "${orderModel.bookingDate} ${orderModel.bookingTime} Time"
            tvPrice.text = "₹${orderModel.totalAmount}"
            tvStatus.text = "${orderModel.status}"
            val adapter = CartHistoryAdapter()
            rv.adapter = adapter
            adapter.submitList(orderModel.orderedItems)
        }
    }


}