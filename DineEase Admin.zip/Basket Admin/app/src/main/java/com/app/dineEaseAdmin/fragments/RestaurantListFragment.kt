package com.app.dineEaseAdmin.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.app.dineEaseAdmin.adapter.RestaurantAdapter
import com.app.dineEaseAdmin.adapter.RestaurantOrdersAdapter
import com.app.dineEaseAdmin.databinding.FragmentRestaurantListBinding
import com.app.dineEaseAdmin.factory.MainViewModelFactory
import com.app.dineEaseAdmin.model.RestaurantModel
import com.app.dineEaseAdmin.model.UserModel
import com.app.dineEaseAdmin.repository.MainRepository
import com.app.dineEaseAdmin.utils.Utils.gone
import com.app.dineEaseAdmin.utils.Utils.visible
import com.app.dineEaseAdmin.viewmodel.MainViewModel

//restaurant list screen
class RestaurantListFragment : Fragment(), RestaurantOrdersAdapter.OnItemClickListener {
    private val binding by lazy { FragmentRestaurantListBinding.inflate(layoutInflater) }
    private lateinit var mainViewModel: MainViewModel
    private lateinit var adapter: RestaurantOrdersAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val repository = MainRepository()
        val factory = MainViewModelFactory(repository)
        mainViewModel = ViewModelProvider(requireActivity(), factory) [MainViewModel::class.java]
        adapter = RestaurantOrdersAdapter(this@RestaurantListFragment)

        binding.apply {


            //getting restaurant list
            mainViewModel.restaurantList.observe(viewLifecycleOwner) { list ->
                if (list.isNotEmpty()) {
                    loadingLayout.gone()
                    mainLayout.visible()
                    rv.adapter = adapter
                    adapter.submitList(list)
                    search(list)
                } else {
                    loadingLayout.visible()
                    mainLayout.gone()
                    tvStatus.text = "No Orders Found"
                }

            }
        }


    }

    //search functionality in restaurant
    private fun search(list: List<RestaurantModel>) {
        binding.searchView.setOnQueryTextListener(object :
            androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if(list.isNotEmpty()) {
                    filteredList(newText, list)
                }
                return true
            }

        })

    }

    //filtering restaurant list according to the users list
    private fun filteredList(newText: String?, list: List<RestaurantModel>) {
        val filteredList = ArrayList<RestaurantModel>()
        for (model in list) {
            if (model.restaurantName.contains(newText.orEmpty(), ignoreCase = true) ||
                model.reservationCharges.contains(newText.orEmpty(), ignoreCase = true) ||
                model.rating.contains(newText.orEmpty(), ignoreCase = true) ||
                model.location.contains(newText.orEmpty(), ignoreCase = true)

            )
                filteredList.add(model)
        }
        adapter.submitList(filteredList)
        binding.rv.adapter = adapter

    }

    override fun onItemClick(model: RestaurantModel) {

    }


}