package com.app.dineEaseAdmin.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.app.dineEaseAdmin.adapter.UserAdapter
import com.app.dineEaseAdmin.databinding.FragmentUsersListBinding
import com.app.dineEaseAdmin.factory.AuthViewModelFactory
import com.app.dineEaseAdmin.model.UserModel
import com.app.dineEaseAdmin.repository.AuthRepository
import com.app.dineEaseAdmin.utils.Utils.gone
import com.app.dineEaseAdmin.utils.Utils.visible
import com.app.dineEaseAdmin.viewmodel.AuthViewModel
import com.google.firebase.auth.FirebaseAuth

//all users list screen
class UsersListFragment : Fragment() {
    private val binding by  lazy { FragmentUsersListBinding.inflate(layoutInflater) }
    private lateinit var authViewModel: AuthViewModel
    private lateinit var adapter: UserAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val repository = AuthRepository(FirebaseAuth.getInstance(), requireContext())
        val factory = AuthViewModelFactory(repository)
        authViewModel = ViewModelProvider(requireActivity(), factory) [AuthViewModel::class.java]
        adapter = UserAdapter()

        binding.apply {

            //getting all users list
            authViewModel.usersList.observe(viewLifecycleOwner) { list ->
                if (list.isNotEmpty()) {
                    loadingLayout.gone()
                    mainLayout.visible()
                    rv.adapter = adapter
                    adapter.submitList(list)
                    search(list)
                } else {
                    loadingLayout.visible()
                    mainLayout.gone()
                    tvStatus.text = "No Data Found"
                }


            }
        }

    }

    //search functionality in users
    private fun search(list: List<UserModel>) {
        binding.searchView.setOnQueryTextListener(object :
            androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if(list.isNotEmpty()) {
                    filteredList(newText, list)
                }
                return true
            }

        })

    }

    //filtering users list according to the users list
    private fun filteredList(newText: String?, list: List<UserModel>) {
        val filteredList = ArrayList<UserModel>()
        for (model in list) {
            if (model.name.contains(newText.orEmpty(), ignoreCase = true) ||
                model.city.contains(newText.orEmpty(), ignoreCase = true) ||
                model.phoneNumber.contains(newText.orEmpty(), ignoreCase = true)

            )
                filteredList.add(model)
        }
        adapter.submitList(filteredList)
        binding.rv.adapter = adapter

    }

}