package com.app.dineEaseAdmin.model

data class AdminTokenModel(
    val tokenId: String = "",
    val token: String = ""
)
