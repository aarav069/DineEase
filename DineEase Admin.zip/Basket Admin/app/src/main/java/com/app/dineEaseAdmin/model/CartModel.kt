package com.app.dineEaseAdmin.model

data class CartModel(
    val id: String = "",
    val productImage: String = "",
    val title: String = "",
    var qty: String = "",
    var price: String = "",
    var originalPrice: String = ""
)
