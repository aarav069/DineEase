package com.app.dineEaseAdmin.model

data class EmailModel(
    val id: String = "",
    val email: String = ""
)