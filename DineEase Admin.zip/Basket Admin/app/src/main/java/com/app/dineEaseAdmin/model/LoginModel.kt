package com.app.dineEaseAdmin.model

data class LoginModel(
    var id: String = "",
    var email: String = "",
    var password: String = ""
)
