package com.app.dineEaseAdmin.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.parcelize.RawValue

@Parcelize
data class OrderModel(
    val id: String = "",
    val userId: String = "",
    val restaurantId: String = "",
    val bookingDate: String = "",
    val bookingTime: String = "",
    val members: String = "",
    val totalAmount: String = "",
    val status: String = "",
    val orderedItems: @RawValue List<CartModel> = ArrayList(),
    val userToken: String = ""
):Parcelable