package com.app.dineEaseAdmin.pushnotification

data class Notification (
    val message: NotificationData? = null
)