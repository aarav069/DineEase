package com.app.dineEaseAdmin.pushnotification

import android.content.Context
import com.app.dineEaseAdmin.utils.Utils
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

object SendNotification {

    fun pushNotification(userToken: String, title: String, body: String, context: Context) {
        val notification = Notification(
            message = NotificationData(
                token = userToken,
                data = hashMapOf(
                    "title" to title,
                    "body" to body
                )
            )
        )

        NotificationAPI.create().sendNotification(notification)
            .enqueue(object : Callback<Notification>{
                override fun onResponse(
                    call: Call<Notification>,
                    response: Response<Notification>
                ) {
                    Utils.showMessage(context, "Notification Sent Successfully")
                }

                override fun onFailure(call: Call<Notification>, t: Throwable) {
                    Utils.showMessage(context, "error ${t.message}")
                }

            })
    }

}