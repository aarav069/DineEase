package com.app.dineEaseAdmin.repository

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.app.dineEaseAdmin.model.EmailModel
import com.app.dineEaseAdmin.model.UserModel
import com.app.dineEaseAdmin.utils.Constants
import com.app.dineEaseAdmin.utils.SharedPref
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.auth.User
import com.google.firebase.ktx.Firebase
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class AuthRepository(private val auth: FirebaseAuth, val context: Context) {

    private val fireStore = FirebaseFirestore.getInstance()
    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    private val _usersList: MutableLiveData<List<UserModel>> = MutableLiveData()
    val usersList: LiveData<List<UserModel>> = _usersList

    private val _user: MutableLiveData<UserModel> = MutableLiveData()
    val user: LiveData<UserModel> = _user

    init {
        coroutineScope.launch {
            fetchAllUsers()
        }
    }

//fetching all users from server
    private suspend fun fetchAllUsers() {
        try {
            val querySnapshot = fireStore.collection(Constants.USER_REF).get().await()
            val users = mutableListOf<UserModel>()

            for (document in querySnapshot.documents) {
                val user = document.toObject(UserModel::class.java)
                user?.let { users.add(it) }
            }
            _usersList.postValue(users)

        } catch (e: Exception) {
            println("Error fetching users: ${e.message}")
        }
    }

//fetching all users from firebase
    fun fetchUserData(uid: String) {
        fireStore.collection(Constants.USER_REF).document(uid)
            .get()
            .addOnSuccessListener { documentSnapshot ->
                FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
                    if (!task.isSuccessful) {
                        return@OnCompleteListener
                    }
                    if (documentSnapshot.exists()) {
                        val user = documentSnapshot.toObject(UserModel::class.java)
                        _user.postValue(user ?: UserModel())
                    } else {
                        _user.postValue(UserModel())
                    }
                })
            }
            .addOnFailureListener {
                _user.postValue(UserModel())
            }
    }


}