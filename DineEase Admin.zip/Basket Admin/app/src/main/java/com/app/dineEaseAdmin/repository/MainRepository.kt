package com.app.dineEaseAdmin.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.app.dineEaseAdmin.model.CartModel
import com.app.dineEaseAdmin.model.FoodModel
import com.app.dineEaseAdmin.model.OrderModel
import com.app.dineEaseAdmin.model.RestaurantModel
import com.app.dineEaseAdmin.utils.Constants
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainRepository {
    private val database = FirebaseDatabase.getInstance()
    private val orderRef = database.getReference(Constants.ORDERS_REF)
    private val restaurantRef = database.getReference(Constants.RESTAURANT_REF)
    private val restaurantFoodRef = database.getReference(Constants.FOOD_REF)
    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    val status: MutableLiveData<Boolean> = MutableLiveData()

    private val _ordersList: MutableLiveData<List<OrderModel>> = MutableLiveData()
    val ordersList: LiveData<List<OrderModel>> = _ordersList


    private val _restaurantsList = MutableLiveData<List<RestaurantModel>>()
    val restaurantsList: LiveData<List<RestaurantModel>> = _restaurantsList

    private val _restaurantFoodList = MutableLiveData<List<FoodModel>>()
    val restaurantFoodList: LiveData<List<FoodModel>> = _restaurantFoodList





    init {
        coroutineScope.launch {
            fetchRestaurants()
        }
    }



    //creating Restaurant in firebase realtime db
    suspend fun createRestaurant(image: String, name: String, rating: String, location: String, reservationCharge: String) {
        val id = restaurantRef.push().key ?: return

        val model = RestaurantModel(id, image, name, rating, reservationCharge, location)

        try {
            restaurantRef.child(id).setValue(model).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    status.postValue(true)
                } else {
                    status.postValue(false)
                }
            }.await()
        } catch (e: Exception) {
            status.postValue(false)
            println("Error creating: ${e.message}")
        }

    }


    //creating restaurant food in firebase realtime db
    suspend fun createRestaurantFood(restaurantId: String, image: String, name: String, originalPrice: String, offerPrice: String, description: String, rating: String) {
        val id = restaurantFoodRef.push().key ?: return

        val model = FoodModel(id, image, name, originalPrice, offerPrice, description, rating)

        try {
            restaurantFoodRef.child(restaurantId).child(id).setValue(model).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    status.postValue(true)
                } else {
                    status.postValue(false)
                }
            }.await()
        } catch (e: Exception) {
            status.postValue(false)
            println("Error creating: ${e.message}")
        }

    }



    //fetching user orders from firebase realtime db
    fun fetchUserOrders(userId: String) {
        try {
            val orderList = mutableListOf<OrderModel>()
            orderRef.child(userId).addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if(snapshot.exists()) {
                        orderList.clear()
                        for (childSnapshot in snapshot.children) {
                            val order = childSnapshot.getValue(OrderModel::class.java)
                            order?.let { orderList.add(it) }
                        }
                        _ordersList.postValue(orderList)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    _ordersList.postValue(emptyList())
                }

            })
        } catch (e: Exception) {
            _ordersList.postValue(emptyList())
        }

    }


    //fetching restaurants from firebase realtime db
    private fun fetchRestaurants() {
        try {
            val models = mutableListOf<RestaurantModel>()
            restaurantRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if(snapshot.exists()) {
                        models.clear()
                        for (childSnapshot in snapshot.children) {
                            val restaurantModel = childSnapshot.getValue(RestaurantModel::class.java)
                            restaurantModel?.let { models.add(it) }
                        }
                        _restaurantsList.postValue(models)
                    } else {
                        _restaurantsList.postValue(emptyList())
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    status.postValue(false)
                }

            })


        } catch (e: Exception) {
            status.postValue(false)
            println("Error fetching : ${e.message}")
        }
    }


    //fetching restaurant food from firebase realtime db
    fun fetchRestaurantFood(id: String) {
        try {
            val models = mutableListOf<FoodModel>()
            restaurantFoodRef.child(id).addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if(snapshot.exists()) {
                        models.clear()
                        for (childSnapshot in snapshot.children) {
                            val foodModel = childSnapshot.getValue(FoodModel::class.java)
                            foodModel?.let { models.add(it) }
                        }
                        _restaurantFoodList.postValue(models)
                    } else {
                        _restaurantFoodList.postValue(emptyList())
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    status.postValue(false)
                }

            })


        } catch (e: Exception) {
            status.postValue(false)
            println("Error fetching : ${e.message}")
        }
    }

    //updating restaurants in firebase realtime db
    suspend fun updateRestaurant(id: String, image: String, name: String, location: String, reservationCharge: String) {
        val map = mapOf<String, Any>(
            "image" to image,
            "restaurantName" to name,
            "rating" to location,
            "reservationCharges" to reservationCharge

        )

        try {
            restaurantRef.child(id).updateChildren(map).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    status.postValue(true)
                } else {
                    status.postValue(false)
                }
            }.await()
        } catch (e: Exception) {
            status.postValue(false)
            println("Error creating : ${e.message}")
        }

    }

    //updating restaurants in firebase realtime db
    suspend fun updateOrderStatus(userId: String, orderId: String, updatedStatus: String) {
        val map = mapOf<String, Any>(
            "status" to updatedStatus

        )

        try {
            orderRef.child(userId).child(orderId).updateChildren(map).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    status.postValue(true)
                } else {
                    status.postValue(false)
                }
            }.await()
        } catch (e: Exception) {
            status.postValue(false)
            println("Error creating : ${e.message}")
        }

    }

    //updating restaurant food in firebase realtime db
    suspend fun updateRestaurantFood(restaurantId: String, id: String,image: String, name: String, originalPrice: String, offerPrice: String, description: String, rating: String) {
        val map = mapOf<String, Any>(
            "image" to image,
            "originalPrice" to originalPrice,
            "rating" to rating,
            "offerPrice" to offerPrice,
            "name" to name,
            "description" to description

        )

        try {
            restaurantFoodRef.child(restaurantId).child(id).updateChildren(map).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    status.postValue(true)
                } else {
                    status.postValue(false)
                }
            }.await()
        } catch (e: Exception) {
            status.postValue(false)
            println("Error creating : ${e.message}")
        }

    }


    //deleting restaurants from firebase realtime db
    suspend fun deleteRestaurant(id: String) {
        try {
            restaurantRef.child(id).removeValue().addOnCompleteListener {
                if(it.isSuccessful) {
                    status.postValue(true)
                } else {
                    status.postValue(false)
                }
            }.await()

        } catch (e: Exception) {
            status.postValue(false)
            println("Error : ${e.message}")
        }
    }

    //fetching user orders of restaurant from firebase realtime db
    fun fetchOrdersByRestaurantId(restaurantId: String) {
        try {
            val orderList = mutableListOf<OrderModel>()
            orderRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        orderList.clear()
                        for (userSnapshot in snapshot.children) {
                            for (orderSnapshot in userSnapshot.children) {
                                val order = orderSnapshot.getValue(OrderModel::class.java)
                                order?.let {
                                    if (it.restaurantId == restaurantId) {
                                        orderList.add(it)
                                    }
                                }
                            }
                        }
                        _ordersList.postValue(orderList)
                    } else {
                        _ordersList.postValue(emptyList())
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    _ordersList.postValue(emptyList())
                }
            })
        } catch (e: Exception) {
            _ordersList.postValue(emptyList())
        }
    }

    //deleting restaurants food from firebase realtime db
    suspend fun deleteRestaurantFood(restaurantId: String, id: String) {
        try {
            restaurantFoodRef.child(restaurantId).child(id).removeValue().addOnCompleteListener {
                if(it.isSuccessful) {
                    status.postValue(true)
                } else {
                    status.postValue(false)
                }
            }.await()

        } catch (e: Exception) {
            status.postValue(false)
            println("Error : ${e.message}")
        }
    }



}