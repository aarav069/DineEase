package com.app.dineEaseAdmin.utils

import com.app.dineEaseAdmin.model.AdminTokenModel

//constants values
object Constants {
    const val USER_REF = "Users"
    const val ORDERS_REF = "Orders"
    const val IMAGES = "Images/"
    const val SLIDER_DOCUMENT = "Slider"
    const val FOOD_REF = "Restaurant Foods"
    const val RESTAURANT_REF = "Restaurants"
    const val ADMIN_TOKEN_REF = "AdminTokens"
    var ADMIN_TOKEN: AdminTokenModel = AdminTokenModel()
}