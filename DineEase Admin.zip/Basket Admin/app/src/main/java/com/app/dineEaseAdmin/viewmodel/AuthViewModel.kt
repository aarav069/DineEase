package com.app.dineEaseAdmin.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.app.dineEaseAdmin.model.UserModel
import com.app.dineEaseAdmin.repository.AuthRepository
import kotlinx.coroutines.launch

class AuthViewModel(private val authRepository: AuthRepository): ViewModel() {

    val user: LiveData<UserModel> = authRepository.user
    val usersList: LiveData<List<UserModel>> = authRepository.usersList


    //fetching user data
    fun fetchUserData(uid: String) {
        viewModelScope.launch {
            authRepository.fetchUserData(uid)
        }
    }




}