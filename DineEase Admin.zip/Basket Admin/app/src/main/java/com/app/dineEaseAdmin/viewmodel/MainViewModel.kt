package com.app.dineEaseAdmin.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.app.dineEaseAdmin.model.CartModel
import com.app.dineEaseAdmin.model.FoodModel
import com.app.dineEaseAdmin.model.OrderModel
import com.app.dineEaseAdmin.model.RestaurantModel
import com.app.dineEaseAdmin.model.UserModel
import com.app.dineEaseAdmin.repository.MainRepository
import kotlinx.coroutines.launch

class MainViewModel(private val mainRepository: MainRepository): ViewModel() {

    val status: LiveData<Boolean> = mainRepository.status
    val restaurantList: LiveData<List<RestaurantModel>> = mainRepository.restaurantsList
    val restaurantFoodList: LiveData<List<FoodModel>> = mainRepository.restaurantFoodList
    val ordersList: LiveData<List<OrderModel>> = mainRepository.ordersList


    //fetching restaurants from firebase realtime db
    fun getRestaurantFood(restaurantId: String) {
        viewModelScope.launch {
            try {
                mainRepository.fetchRestaurantFood(restaurantId)
            } catch (e: Exception) {
                mainRepository.status.postValue(false)
            }
        }
    }


    //creating Restaurant in firebase realtime db
    fun createRestaurant(image: String, name: String, rating: String, location: String, reservationCharge: String) {
        viewModelScope.launch {
            try {
                mainRepository.createRestaurant(image, name, rating, location, reservationCharge)
            } catch (e: Exception) {
                mainRepository.status.postValue(false)
            }
        }
    }

    //creating restaurant food in firebase realtime db
    fun createRestaurantFood(restaurantId: String, image: String, name: String, originalPrice: String, offerPrice: String, description: String, rating: String) {
        viewModelScope.launch {
            try {
                mainRepository.createRestaurantFood(restaurantId, image, name, originalPrice, offerPrice, description, rating)
            } catch (e: Exception) {
                mainRepository.status.postValue(false)
            }
        }
    }


//deleting restaurant from firebase realtime db
    fun deleteRestaurant(id: String) {
        viewModelScope.launch {
            try {
                mainRepository.deleteRestaurant(id)
            }  catch (e: Exception) {
                mainRepository.status.postValue(false)
            }
        }
    }

    //deleting restaurant food from firebase realtime db
    fun deleteRestaurantFood(restaurantId: String, id: String) {
        viewModelScope.launch {
            try {
                mainRepository.deleteRestaurantFood(restaurantId, id)
            }  catch (e: Exception) {
                mainRepository.status.postValue(false)
            }
        }
    }



    //updating restaurant data
    fun updateRestaurant(id: String, image: String, name: String, location: String, reservationCharge: String) {
        viewModelScope.launch {
            try {
                mainRepository.updateRestaurant(id, image, name, location, reservationCharge)
            }  catch (e: Exception) {
                mainRepository.status.postValue(false)
            }
        }
    }

    //updating restaurant food data
    fun updateRestaurantFood(restaurantId: String, id: String, image: String, name: String, originalPrice: String, offerPrice: String, description: String, rating: String) {
        viewModelScope.launch {
            try {
                mainRepository.updateRestaurantFood(restaurantId, id, image, name, originalPrice, offerPrice, description, rating)
            }  catch (e: Exception) {
                mainRepository.status.postValue(false)
            }
        }
    }

    //fetching user orders of restaurant from firebase realtime db
    fun fetchOrdersByRestaurantId(restaurantId: String) {
        viewModelScope.launch {
            try {
                mainRepository.fetchOrdersByRestaurantId(restaurantId)
            }  catch (e: Exception) {
                print(e.message)
            }
        }
    }

    //updating order status in firebase realtime db
    fun updateOrderStatus(userId: String, orderId: String, updatedStatus: String) {
        viewModelScope.launch {
            try {
                mainRepository.updateOrderStatus(userId, orderId, updatedStatus)
            }  catch (e: Exception) {
                print(e.message)
            }
        }
    }



}