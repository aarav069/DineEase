package com.app.dineEase.activities


import android.graphics.Color
import android.os.Bundle
import android.text.Html
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.app.dineEase.R
import com.app.dineEase.databinding.ActivityAboutUsBinding

//about us activity
class AboutUsActivity : AppCompatActivity() {
    private val binding by lazy { ActivityAboutUsBinding.inflate(layoutInflater) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.WHITE)
        )
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom)
            insets
        }

        //about text in html format
        val aboutUsText = """
    <p>Welcome to <b>Basket</b>, your premier solution for seamless restaurant table bookings and food pre-ordering. We understand the importance of a well-planned dining experience, whether you’re celebrating a special occasion or just enjoying a meal out. That’s why we’ve created Basket – to make your dining experience more convenient, personalized, and enjoyable.</p><br>
    
    <h3>Our Mission:</h3>
    <p>At Basket, our mission is to enhance your dining experience by offering an easy-to-use platform that simplifies the process of booking a table and pre-ordering your favorite dishes. We aim to provide a service that saves you time, eliminates the hassle, and ensures that every meal is memorable.</p><br>
    
    <h3>What We Offer:</h3>
    <div>
        <div><b>• Easy Table Booking:</b> Reserve your table at your favorite restaurant with just a few clicks, ensuring you have the perfect spot for your next meal.</div>
        <div><b>• Food Pre-Ordering:</b> Browse the menu and pre-order your dishes in advance, so your food is ready when you arrive, giving you more time to enjoy your dining experience.</div>
        <div><b>• Exclusive Offers:</b> Take advantage of special promotions and deals available only to Basket users, making your dining experience even more rewarding.</div>
        <div><b>• Personalized Experience:</b> Save your preferences and favorite dishes, and receive tailored recommendations to enhance your future dining experiences.</div>
        <div><b>• Seamless Payments:</b> Enjoy a hassle-free payment process with secure, in-app payment options, allowing you to settle your bill effortlessly.</div>
    </div><br>
    
    <h3>Why Choose Basket:</h3>
    <div>
        <div><b>• Convenience:</b> Book a table and pre-order your food from the comfort of your home or on the go, ensuring a smooth and stress-free dining experience.</div>
        <div><b>• Time-Saving:</b> Skip the wait by having your meal prepared in advance, allowing you to focus on enjoying your time with friends and family.</div>
        <div><b>• Variety:</b> Discover a wide selection of restaurants and cuisines, ensuring there’s something to satisfy every palate.</div>
        <div><b>• Customer Support:</b> Our dedicated customer support team is here to assist you with any questions or concerns, ensuring a seamless experience from start to finish.</div>
    </div><br>
    
    <h3>Join Us:</h3>
    <p>We invite you to explore our platform and experience the convenience and ease of Basket. Whether you’re planning a romantic dinner, a family gathering, or a night out with friends, Basket is here to make your dining experience exceptional. Join our community of satisfied users and make Basket your go-to solution for all your dining needs.</p><br>
    
    <p>Thank you for choosing Basket. We look forward to serving you and helping you create unforgettable dining experiences!</p>
""".trimIndent()

        //setting about text to textview
        binding.tvAboutUs.text = Html.fromHtml(aboutUsText, Html.FROM_HTML_MODE_COMPACT)

    }
}