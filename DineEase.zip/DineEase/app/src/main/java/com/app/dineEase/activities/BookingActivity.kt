package com.app.dineEase.activities

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import coil.load
import com.app.dineEase.R
import com.app.dineEase.adapter.CartAdapter
import com.app.dineEase.adapter.TimeSlotAdapter
import com.app.dineEase.databinding.ActivityBookingBinding
import com.app.dineEase.factory.MainViewModelFactory
import com.app.dineEase.model.CartModel
import com.app.dineEase.model.RestaurantModel
import com.app.dineEase.model.TimeSlotModel
import com.app.dineEase.model.UserModel
import com.app.dineEase.pushnotification.SendNotification
import com.app.dineEase.repository.MainRepository
import com.app.dineEase.utils.Constants
import com.app.dineEase.utils.SharedPref
import com.app.dineEase.utils.Utils
import com.app.dineEase.viewmodel.MainViewModel
import com.google.firebase.database.FirebaseDatabase
import com.razorpay.Checkout
import com.razorpay.PaymentData
import com.razorpay.PaymentResultWithDataListener
import org.json.JSONObject

//restauarant booking activity
class BookingActivity : AppCompatActivity(), PaymentResultWithDataListener, CartAdapter.OnItemClickListener, TimeSlotAdapter.OnItemClickListener {
    private val binding by lazy { ActivityBookingBinding.inflate(layoutInflater) }
    private lateinit var database: FirebaseDatabase
    private var time = ""
    private lateinit var adapter: TimeSlotAdapter
    private lateinit var cartAdapter: CartAdapter
    private lateinit var restaurant: RestaurantModel
    private lateinit var mainViewModel: MainViewModel
    private lateinit var user: UserModel
    private lateinit var cartList: ArrayList<CartModel>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.WHITE)
        )

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom)
            insets
        }

        database = FirebaseDatabase.getInstance()
        user = SharedPref.getUserData(this@BookingActivity) ?: UserModel()

        val repository = MainRepository(this)
        val factory = MainViewModelFactory(repository)
        mainViewModel = ViewModelProvider(this, factory)[MainViewModel::class.java]

        cartList = ArrayList()
        adapter = TimeSlotAdapter(this@BookingActivity)
        cartAdapter = CartAdapter(this@BookingActivity)
        binding.recyclerView.adapter = adapter
        adapter.submitList(Constants.TIME_SLOT_LIST)

        binding.rv.adapter = cartAdapter

        //managing payment status
        mainViewModel.orderPlaced.observe(this@BookingActivity) { status ->
            if(status) {

                startActivity(Intent(this@BookingActivity, OrderHistoryActivity::class.java))
                finish()
            } else {
                Utils.showMessage(this@BookingActivity, "Something went wrong")
            }
        }

        //managing cart items
        mainViewModel.cartItemsList.observe(this@BookingActivity) {
            if(it.isNotEmpty()) {
                cartList.clear()
                cartList.addAll(it)
                binding.rv.adapter = cartAdapter
                cartAdapter.submitList(cartList)
                calculateGrandTotal(cartAdapter)
            } else {
                binding.rv.adapter = cartAdapter
                cartAdapter.submitList(emptyList())
            }
        }

        restaurant = intent.getParcelableExtra<RestaurantModel>(Constants.RESTAURANT) ?: RestaurantModel()
        binding.apply {

            ivImage.load(restaurant.image) {
                placeholder(R.drawable.placeholder)
                error(R.drawable.placeholder)
            }
            tvResarvationCharge.text = "₹${restaurant.reservationCharges}"
            tvPrice.text = "₹${restaurant.reservationCharges} Resarvation Charges"
            tvRating.text = "${restaurant.rating} Rating"
            tvName.text = restaurant.restaurantName

            etEmail.setText(user?.email)
            etName.setText(user?.name)
            etPhoneNumber.setText(user?.phoneNumber)


            etDate.setOnClickListener {
                Utils.showDatePickerDialog(this@BookingActivity) { selectedDate ->
                    etDate.setText(selectedDate)
                }
            }

            btBookNow.setOnClickListener {
                validateBooking()
            }
        }
    }

    //after payment success
    override fun onPaymentSuccess(p0: String?, p1: PaymentData?) {
        uploadBooking()
    }

    //after payment failed
    override fun onPaymentError(p0: Int, p1: String?, p2: PaymentData?) {
        Toast.makeText(this, "Payment Failed", Toast.LENGTH_SHORT).show()
    }

    //making initiate of payment
    private fun initPayment() {
        val activity: Activity = this
        val co = Checkout()
        co.setKeyID("rzp_test_svSlDCxkfQ8PqB")

        try {
            val options = JSONObject()
            options.put("name", getString(R.string.app_name))
            options.put("description", "DineEase")
            options.put("image", R.drawable.icon)
            options.put("theme.color", "#FFC600");
            options.put("currency", "INR");

            val finalAmount = calculateGrandTotal(cartAdapter).toInt() + restaurant.reservationCharges.toInt()
            val amountInPaisa = (finalAmount * 100)
            options.put("amount", amountInPaisa)


            val retryObj = JSONObject();
            retryObj.put("enabled", true);
            retryObj.put("max_count", 4);
            options.put("retry", retryObj);

            val prefill = JSONObject()
            prefill.put("email", "dineEase@gmail.com")
            prefill.put("contact", "9876543210")

            options.put("prefill", prefill)
            co.open(activity, options)
        } catch (e: Exception) {
            Toast.makeText(activity, "Payment Failed", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }

    }

    //validating booking details
    private fun validateBooking() {
        binding.apply {
            val error = "Empty"
            if(etName.text.toString().isEmpty()) {
                etName.requestFocus()
                etName.error = error
            } else if(etEmail.text.toString().isEmpty()) {
                etEmail.requestFocus()
                etEmail.error = error
            } else if(etPhoneNumber.text.toString().isEmpty() || etPhoneNumber.text.toString().length != 10) {
                etPhoneNumber.requestFocus()
                etPhoneNumber.error = "Check"
            } else if(etMember.text.toString().isEmpty()) {
                etMember.requestFocus()
                etMember.error = error
            } else if(time == "") {
                Utils.showMessage(this@BookingActivity, "Please Select Time")
            } else {
                initPayment()
            }
        }
    }

    //uplading booking data to firebase db
    private fun uploadBooking() {
        val finalAmount = calculateGrandTotal(cartAdapter).toInt() + restaurant.reservationCharges.toInt()
        binding.btBookNow.text = "Placing Order..."
        binding.btBookNow.isClickable = false

        SendNotification.pushNotification(Constants.ADMIN_TOKEN.token, "New Order Placed", "${user.name} Place New Order at ${binding.etDate.text.toString()} $time", this@BookingActivity)

        Log.d("nn", "uploadBooking: ${Constants.ADMIN_TOKEN.token}")
        mainViewModel.placeOrder(
            user.userId,
            restaurant.id,
            binding.etDate.text.toString(),
            time,
            binding.etMember.text.toString(),
            "Pending",
            finalAmount.toString(),
            cartList,
            user.token
        )
    }

    //calculating food total and grand total
    private fun calculateGrandTotal(adapter: CartAdapter): String {
        var grandTotal = 0
        val itemList = adapter.currentList
        for (item in itemList) {
            val totalPrice = item.qty.toInt() * item.price.toInt()
            grandTotal += totalPrice
        }
        binding.tvFoodTotal.text = "₹$grandTotal"
        val finalValue = (restaurant.reservationCharges.toIntOrNull() ?: 0 )+ grandTotal.toInt()
        binding.tvGrandTotal.text = "₹$finalValue"
        return grandTotal.toString()
    }

    //getting time slot
    override fun onItemClick(timeSlot: TimeSlotModel) {
        time = timeSlot.timeSlot
    }

    //removing from cart
    override fun removeFromCart(product: CartModel) {
        mainViewModel.removeFromCart(user.userId, product.id)
        binding.rv.adapter = cartAdapter
        cartAdapter.submitList(cartList)
        calculateGrandTotal(cartAdapter)
    }

    override fun onQuantityChanged(product: CartModel) {
//        val updatedList = cartAdapter.currentList.map {
//            if (it.id == product.id) {
//                it.copy(qty = product.qty)
//            } else {
//                it
//            }
//        }
//        calculateGrandTotal(cartAdapter)
//        cartAdapter.submitList(updatedList)
    }

}