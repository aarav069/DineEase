package com.app.dineEase.activities

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import coil.load
import com.app.dineEase.R
import com.app.dineEase.adapter.CartHistoryAdapter
import com.app.dineEase.adapter.OrderHistoryAdapter
import com.app.dineEase.databinding.ActivityOrderHistoryBinding
import com.app.dineEase.factory.MainViewModelFactory
import com.app.dineEase.model.OrderModel
import com.app.dineEase.model.RestaurantModel
import com.app.dineEase.model.UserModel
import com.app.dineEase.repository.MainRepository
import com.app.dineEase.utils.Constants
import com.app.dineEase.utils.SharedPref
import com.app.dineEase.utils.Utils
import com.app.dineEase.utils.Utils.gone
import com.app.dineEase.utils.Utils.visible
import com.app.dineEase.viewmodel.MainViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
//user order history
class OrderHistoryActivity : AppCompatActivity(), OrderHistoryAdapter.SetOrderData {
    val binding by lazy { ActivityOrderHistoryBinding.inflate(layoutInflater) }
    private lateinit var mainViewModel: MainViewModel
    private lateinit var adapter: OrderHistoryAdapter
    private lateinit var user: UserModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.WHITE)
        )
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom)
            insets
        }

        val repository = MainRepository(this)
        val factory = MainViewModelFactory(repository)
        mainViewModel = ViewModelProvider(this, factory)[MainViewModel::class.java]
        adapter = OrderHistoryAdapter(this@OrderHistoryActivity)
        user = SharedPref.getUserData(this) ?: UserModel()

        mainViewModel.fetchUserOrders(user.userId)

        //getting user order
        mainViewModel.orderHistory.observe(this@OrderHistoryActivity) { list ->
            if(list.isNotEmpty()) {
                binding.loadingLayout.gone()
                binding.mainLayout.visible()
                binding.rv.adapter = adapter
                adapter.submitList(list.reversed())
            } else {
                binding.loadingLayout.visible()
                binding.mainLayout.gone()
                binding.tvStatus.text = "No Orders Found"
                binding.rv.adapter = adapter
                adapter.submitList(emptyList())
            }

        }

        //back press managing
        onBackPressedDispatcher.addCallback(this@OrderHistoryActivity, object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {
                startActivity(Intent(this@OrderHistoryActivity, HomeMainActivity::class.java))
                finish()
            }

        })


        binding.apply {




        }


    }

    //setting order data to rv
    override fun setOrderData(holder: OrderHistoryAdapter.OrderVH, orderModel: OrderModel) {
        holder.binding.apply {

            mainViewModel.fetchRestaurantById(orderModel.restaurantId)

            mainViewModel.restaurantData.observe(this@OrderHistoryActivity) { item ->
                mainViewModel.fetchRestaurantById(orderModel.restaurantId)
                Log.d("myapp", "setOrderData: $item")
                image.load(item.image) {
                    placeholder(R.drawable.placeholder)
                    error(R.drawable.placeholder)
                }


                tvTitle.text = item.restaurantName
                tvRating.text =  "${item.rating} Ratings"


            }

            tvMembers.text =  "${orderModel.members} Members"
            tvDate.text = "${orderModel.bookingDate}"
            tvPrice.text = "₹${orderModel.totalAmount}"
            tvStatus.text = "${orderModel.status}"
            val adapter = CartHistoryAdapter()
            rv.adapter = adapter
            adapter.submitList(orderModel.orderedItems)


        }
    }
}