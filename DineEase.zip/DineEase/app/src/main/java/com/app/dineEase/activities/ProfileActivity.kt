package com.app.dineEase.activities

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import com.app.dineEase.R
import com.app.dineEase.databinding.ActivityProfileBinding
import com.app.dineEase.factory.AuthViewModelFactory
import com.app.dineEase.model.UserModel
import com.app.dineEase.repository.AuthRepository
import com.app.dineEase.utils.SharedPref
import com.app.dineEase.viewmodel.AuthViewModel
import com.google.firebase.auth.FirebaseAuth

//user profile screen
class ProfileActivity : AppCompatActivity() {
    private val binding by lazy { ActivityProfileBinding.inflate(layoutInflater) }
    private lateinit var user: UserModel
    private lateinit var authViewModel: AuthViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.WHITE)
        )
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom)
            insets
        }

        val repository = AuthRepository(FirebaseAuth.getInstance(),  this@ProfileActivity)
        val factory = AuthViewModelFactory(repository)
        authViewModel = ViewModelProvider(this@ProfileActivity, factory)[AuthViewModel::class.java]

        //getting user data
        user = SharedPref.getUserData(this@ProfileActivity) ?: UserModel()

        setData(user)

    }

    //setting user data to view
    private fun setData(user: UserModel) {
        binding.apply {
            etHomeStayName.setText(user.name)
            etCityName.setText(user.city)
            etEmailId.setText(user.email)
            etMobileNumber.setText(user.phoneNumber)

            btLogout.setOnClickListener {
                authViewModel.signOut()
                val intent = Intent(this@ProfileActivity, WelcomeActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                startActivity(intent)
                finish()
            }


        }
    }
}