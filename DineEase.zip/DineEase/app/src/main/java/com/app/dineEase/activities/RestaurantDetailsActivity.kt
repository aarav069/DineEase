package com.app.dineEase.activities

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import coil.load
import com.app.dineEase.R
import com.app.dineEase.adapter.RestaurantFoodAdapter
import com.app.dineEase.databinding.ActivityRestaurantDetailsBinding
import com.app.dineEase.factory.MainViewModelFactory
import com.app.dineEase.model.CartModel
import com.app.dineEase.model.FoodModel
import com.app.dineEase.model.RestaurantModel
import com.app.dineEase.model.UserModel
import com.app.dineEase.repository.MainRepository
import com.app.dineEase.utils.Constants
import com.app.dineEase.utils.SharedPref
import com.app.dineEase.utils.Utils
import com.app.dineEase.utils.Utils.gone
import com.app.dineEase.utils.Utils.visible
import com.app.dineEase.viewmodel.MainViewModel
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
//restaurant details activity
class RestaurantDetailsActivity : AppCompatActivity() {
    private val binding by lazy { ActivityRestaurantDetailsBinding.inflate(layoutInflater) }
    private lateinit var restaurant: RestaurantModel
    private lateinit var mainViewModel: MainViewModel
    private lateinit var adapter: RestaurantFoodAdapter
    private lateinit var user: UserModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.WHITE)
        )

        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom)
            insets
        }

        restaurant = intent.getParcelableExtra<RestaurantModel>(Constants.RESTAURANT_REF) ?: RestaurantModel()

        setDetails(restaurant)
        setupCounter("1", binding.tvQty, binding.btIncrease, binding.btDecrease)
        user = SharedPref.getUserData(this) ?: UserModel()


        val repository = MainRepository(this)
        val factory = MainViewModelFactory(repository)
        mainViewModel = ViewModelProvider(this, factory)[MainViewModel::class.java]
        //getting restaurant food list
        mainViewModel.getRestaurantFood(restaurant.id)

        //managing back press
        onBackPressedDispatcher.addCallback(this@RestaurantDetailsActivity, object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {
                val intent = Intent(this@RestaurantDetailsActivity, HomeMainActivity::class.java)
                intent.putExtra(Constants.GO_TO_CART, Constants.RESTAURANT)
                startActivity(intent)

            }

        })

        binding.apply {

            loadingLayout.gone()
            mainLayout.visible()
            adapter = RestaurantFoodAdapter(this@RestaurantDetailsActivity, restaurant)

            btLocate.setOnClickListener {
                openMapWithUrl(restaurant.location)
            }

            //getting restaurant food list
            mainViewModel.restaurantFoodList.observe(this@RestaurantDetailsActivity) { list ->
                if(list.isNotEmpty()) {
                    rv.adapter = adapter
                    adapter.submitList(list)
                } else {
                    rv.adapter = adapter
                    adapter.submitList(emptyList())
                    Utils.showMessage(this@RestaurantDetailsActivity, "No Food Found")
                }

            }



        }

    }

    //opening map with url
    private fun openMapWithUrl(location: String) {
        val mapUrl = "https://www.google.com/maps/search/?api=1&query=$location"
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(mapUrl)
        }
        startActivity(intent)
    }

    //setting data to view
    private fun setDetails(model: RestaurantModel) {
        binding.apply {
            ivImage.load(model.image) {
                placeholder(R.drawable.placeholder)
                error(R.drawable.placeholder)
            }

//            tvOriginalPrice.paintFlags = tvOriginalPrice.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            tvTitle.text = model.restaurantName
            tvRating.text = model.rating
            tvOfferPrice.text = "₹${ model.reservationCharges }"




        }

    }




//setting up counter
    private fun setupCounter(initialCount: String, textView: TextView, increaseButton: ImageView, decreaseButton: ImageView) {
        var count = initialCount.toIntOrNull() ?: 1

        textView.text = count.toString()

        increaseButton.setOnClickListener {
            count++
            textView.text = count.toString()
        }

        decreaseButton.setOnClickListener {
            if (count > 1) {
                count--
                textView.text = count.toString()
            }
        }
    }


}