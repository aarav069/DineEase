package com.app.dineEase.activities

import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import coil.load
import com.app.dineEase.R
import com.app.dineEase.databinding.ActivityDetailsFoodRestaurantBinding
import com.app.dineEase.factory.MainViewModelFactory
import com.app.dineEase.model.CartModel
import com.app.dineEase.model.FoodModel
import com.app.dineEase.model.RestaurantModel
import com.app.dineEase.model.UserModel
import com.app.dineEase.repository.MainRepository
import com.app.dineEase.utils.Constants
import com.app.dineEase.utils.SharedPref
import com.app.dineEase.utils.Utils
import com.app.dineEase.utils.Utils.gone
import com.app.dineEase.utils.Utils.visible
import com.app.dineEase.viewmodel.MainViewModel
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
//restaurant food details activity
class RestaurantFoodDetailsActivity : AppCompatActivity() {
    private val binding by lazy { ActivityDetailsFoodRestaurantBinding.inflate(layoutInflater) }
    private lateinit var foodModel: FoodModel
    private lateinit var restaurant: RestaurantModel
    private lateinit var mainViewModel: MainViewModel
    private lateinit var user: UserModel
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.WHITE)
        )

        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom)
            insets
        }

        foodModel = intent.getParcelableExtra<FoodModel>(Constants.RESTAURANT_REF) ?: FoodModel()
        restaurant = intent.getParcelableExtra<RestaurantModel>(Constants.RESTAURANT) ?: RestaurantModel()

        setDetails(foodModel)
        setupCounter("1", binding.tvQty, binding.btIncrease, binding.btDecrease)
        user = SharedPref.getUserData(this) ?: UserModel()


        val repository = MainRepository(this)
        val factory = MainViewModelFactory(repository)
        mainViewModel = ViewModelProvider(this, factory)[MainViewModel::class.java]

        mainViewModel.getRestaurantFood(foodModel.id)

        onBackPressedDispatcher.addCallback(this@RestaurantFoodDetailsActivity, object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {
                finish()
            }

        })

        binding.apply {

            loadingLayout.gone()
            mainLayout.visible()



            val restaurantName = intent.getStringExtra(Constants.RESTAURANT) ?: "Restaurant Name"
            tvResTitle.text = restaurantName



            //managing add cart button action
            btAddToCart.setOnClickListener {
                val intent = Intent(this@RestaurantFoodDetailsActivity, BookingActivity::class.java)
                intent.putExtra(Constants.RESTAURANT, restaurant)

                if(btAddToCart.text == Constants.GO_TO_CART) {
                    startActivity(intent)
                } else {
                    val cartId = Firebase.database.getReference(Constants.CART_REF).push().key
                    val cart = CartModel(cartId!!, foodModel.image, foodModel.name,
                        tvQty.text.toString(), foodModel.offerPrice,
                        foodModel.originalPrice)

                    mainViewModel.addToCart(user.userId, cart)
                    btAddToCart.text = Constants.GO_TO_CART
                }
            }


        }

    }

    //setting food details
    private fun setDetails(model: FoodModel) {
        binding.apply {
            ivImage.load(model.image) {
                placeholder(R.drawable.placeholder)
                error(R.drawable.placeholder)
            }

            tvOriginalPrice.paintFlags = tvOriginalPrice.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            val offerPrice = model.offerPrice.toIntOrNull() ?: 0
            val originalPrice = model.originalPrice.toIntOrNull() ?: 0
            val dc = Utils.calculateDiscount(offerPrice, originalPrice)
            tvTitle.text = model.name
            tvRating.text = model.rating
            tvOriginalPrice.text = "₹${ model.originalPrice}"
            tvPercentage.text = "${dc.toInt()}% Off"
            tvDescription.text = model.description
            tvPercentage.text = "${dc.toInt()}% Off"
            tvOfferPrice.text = "₹${ model.offerPrice}"
        }

    }


    //setting up counter
    private fun setupCounter(initialCount: String, textView: TextView, increaseButton: ImageView, decreaseButton: ImageView) {
        var count = initialCount.toIntOrNull() ?: 1

        textView.text = count.toString()

        increaseButton.setOnClickListener {
            count++
            textView.text = count.toString()
        }

        decreaseButton.setOnClickListener {
            if (count > 1) {
                count--
                textView.text = count.toString()
            }
        }
    }




}