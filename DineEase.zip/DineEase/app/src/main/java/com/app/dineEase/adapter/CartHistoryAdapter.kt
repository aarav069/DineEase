package com.app.dineEase.adapter

import android.graphics.Paint
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.app.dineEase.R
import com.app.dineEase.databinding.ItemCartBinding
import com.app.dineEase.databinding.ItemHistoryCartBinding
import com.app.dineEase.model.CartModel
import com.google.android.material.textfield.TextInputEditText

//order history food items
class CartHistoryAdapter : ListAdapter<CartModel, CartHistoryAdapter.CategoryVH>(DiffUtils) {
    inner class CategoryVH(val binding: ItemHistoryCartBinding) : RecyclerView.ViewHolder(binding.root)

    object DiffUtils : DiffUtil.ItemCallback<CartModel>() {
        override fun areItemsTheSame(oldItem: CartModel, newItem: CartModel): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: CartModel, newItem: CartModel): Boolean {
            return oldItem == newItem
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryVH {
        val binding = ItemHistoryCartBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CategoryVH(binding)
    }

    override fun onBindViewHolder(holder: CategoryVH, position: Int) {
        val item = getItem(position)

        holder.binding.apply {

            ivServiceImage.load(item.productImage) {
                placeholder(R.drawable.placeholder)
                error(R.drawable.placeholder)
            }

            tvOriginalPrice.paintFlags = tvOriginalPrice.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG

            tvTitle.text = item.title
            tvTotalPrice.text =  "₹ ${item.price.toInt() * item.qty.toInt()}"
            tvOriginalPrice.text = "₹ ${item.originalPrice}"
            tvOfferPrice.text = "₹ ${item.price}"
            tvQty.text = "${item.qty} Qty"


        }

    }






}







