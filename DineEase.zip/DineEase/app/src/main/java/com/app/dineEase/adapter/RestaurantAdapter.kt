package com.app.dineEase.adapter

import android.graphics.Paint
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.app.dineEase.R
import com.app.dineEase.databinding.ItemCartBinding
import com.app.dineEase.databinding.ItemRestaurantBinding
import com.app.dineEase.model.RestaurantModel
import com.google.android.material.textfield.TextInputEditText

//connecting restaurant list to rv
class RestaurantAdapter(private val onClick: OnItemClickListener) : ListAdapter<RestaurantModel, RestaurantAdapter.CategoryVH>(DiffUtils) {
    inner class CategoryVH(val binding: ItemRestaurantBinding) : RecyclerView.ViewHolder(binding.root)

    object DiffUtils : DiffUtil.ItemCallback<RestaurantModel>() {
        override fun areItemsTheSame(oldItem: RestaurantModel, newItem: RestaurantModel): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: RestaurantModel, newItem: RestaurantModel): Boolean {
            return oldItem == newItem
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryVH {
        val binding = ItemRestaurantBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CategoryVH(binding)
    }

    override fun onBindViewHolder(holder: CategoryVH, position: Int) {
        val item = getItem(position)

        holder.binding.apply {

//            tvOriginalPrice.paintFlags = tvOriginalPrice.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG

            //setting data to views
            ivImage.load(item.image) {
                placeholder(R.drawable.placeholder)
                error(R.drawable.placeholder)
            }

            tvTitle.text = item.restaurantName
            tvRatings.text = item.rating
            tvLocation.text = item.location
            tvOfferPrice.text = "₹${item.reservationCharges}"

            holder.itemView.setOnClickListener {
                onClick.onItemClick(item)
            }


        }

    }



    interface OnItemClickListener {
        fun onItemClick(model: RestaurantModel)
    }


}







