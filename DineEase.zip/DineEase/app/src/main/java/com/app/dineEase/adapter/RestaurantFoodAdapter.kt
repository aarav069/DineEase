package com.app.dineEase.adapter

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import com.app.dineEase.R
import com.app.dineEase.activities.RestaurantFoodDetailsActivity
import com.app.dineEase.databinding.ItemFoodBinding
import com.app.dineEase.model.FoodModel
import com.app.dineEase.model.RestaurantModel
import com.app.dineEase.utils.Constants
import com.app.dineEase.utils.Utils

//connecting restaurant food to rv
class RestaurantFoodAdapter(val context: Context, private val restaurant: RestaurantModel) : ListAdapter<FoodModel, RestaurantFoodAdapter.CategoryVH>(DiffUtils) {
    inner class CategoryVH(val binding: ItemFoodBinding) : RecyclerView.ViewHolder(binding.root)

    object DiffUtils : DiffUtil.ItemCallback<FoodModel>() {
        override fun areItemsTheSame(oldItem: FoodModel, newItem: FoodModel): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: FoodModel, newItem: FoodModel): Boolean {
            return oldItem == newItem
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryVH {
        val binding = ItemFoodBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CategoryVH(binding)
    }

    override fun onBindViewHolder(holder: CategoryVH, position: Int) {
        val item = getItem(position)

        holder.binding.apply {

            ivImage.load(item.image) {
                placeholder(R.drawable.placeholder)
                error(R.drawable.placeholder)
            }

            tvOriginalPrice.paintFlags = tvOriginalPrice.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            tvTitle.text = item.name
            tvDescription.text = item.description
            tvRating.text = "${item.rating} Rating"
            tvOfferPrice.text = "₹${item.offerPrice}"
            tvOriginalPrice.text = "₹${item.originalPrice}"
            tvPercentage.text = "${Utils.calculateDiscount(item.offerPrice.toInt(), item.originalPrice.toInt()).toInt()}% Off"


            holder.itemView.setOnClickListener {
                val intent = Intent(context, RestaurantFoodDetailsActivity::class.java)
                intent.putExtra(Constants.RESTAURANT_REF, item)
                intent.putExtra(Constants.RESTAURANT, restaurant)
                context.startActivity(intent)
            }


        }

    }





}







