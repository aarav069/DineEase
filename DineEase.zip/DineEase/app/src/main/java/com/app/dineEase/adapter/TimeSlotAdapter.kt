package com.app.dineEase.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.app.dineEase.R
import com.app.dineEase.databinding.ItemButtonBinding
import com.app.dineEase.model.TimeSlotModel

//showing available time slots
class TimeSlotAdapter(private val onClick: OnItemClickListener) : ListAdapter<TimeSlotModel, TimeSlotAdapter.CategoryVH>(DiffUtils) {
    inner class CategoryVH(val binding: ItemButtonBinding) : RecyclerView.ViewHolder(binding.root)

    private var selectedPosition = RecyclerView.NO_POSITION

    object DiffUtils : DiffUtil.ItemCallback<TimeSlotModel>() {
        override fun areItemsTheSame(oldItem: TimeSlotModel, newItem: TimeSlotModel): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: TimeSlotModel, newItem: TimeSlotModel): Boolean {
            return oldItem == newItem
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryVH {
        val binding = ItemButtonBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CategoryVH(binding)
    }

    override fun onBindViewHolder(holder: CategoryVH, position: Int) {
        val item = getItem(position)

        holder.binding.apply {

            tvTime.text = item.timeSlot

            holder.itemView.setBackgroundResource(
                if (position == selectedPosition) R.drawable.shape_solid else R.drawable.shape_outline_border
            )



            holder.itemView.setOnClickListener {

                val previousSelectedPosition = selectedPosition
                selectedPosition = holder.adapterPosition
                notifyItemChanged(previousSelectedPosition)
                notifyItemChanged(selectedPosition)

                onClick.onItemClick(item)
            }


        }

    }



    interface OnItemClickListener {
        fun onItemClick(timeSlot: TimeSlotModel)

    }


}







