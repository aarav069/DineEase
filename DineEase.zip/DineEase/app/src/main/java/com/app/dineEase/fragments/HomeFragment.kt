package com.app.dineEase.fragments

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.viewpager2.widget.ViewPager2
import com.app.dineEase.R
import com.app.dineEase.activities.AboutUsActivity
import com.app.dineEase.activities.OrderHistoryActivity
import com.app.dineEase.activities.ProfileActivity
import com.app.dineEase.activities.RestaurantDetailsActivity
import com.app.dineEase.activities.WelcomeActivity
import com.app.dineEase.adapter.RestaurantAdapter
import com.app.dineEase.adslider.SliderAdapter
import com.app.dineEase.adslider.SliderModel
import com.app.dineEase.databinding.DialogExitBinding
import com.app.dineEase.databinding.FragmentHomeBinding
import com.app.dineEase.databinding.NavigationLayoutBinding
import com.app.dineEase.factory.AuthViewModelFactory
import com.app.dineEase.factory.MainViewModelFactory
import com.app.dineEase.model.AdminTokenModel
import com.app.dineEase.model.RestaurantModel
import com.app.dineEase.model.UserModel
import com.app.dineEase.pushnotification.SendNotification
import com.app.dineEase.repository.AuthRepository
import com.app.dineEase.repository.MainRepository
import com.app.dineEase.utils.Constants
import com.app.dineEase.utils.SharedPref
import com.app.dineEase.utils.Utils
import com.app.dineEase.utils.Utils.gone
import com.app.dineEase.utils.Utils.visible
import com.app.dineEase.viewmodel.AuthViewModel
import com.app.dineEase.viewmodel.MainViewModel
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import kotlin.system.exitProcess

//home screen
class HomeFragment : Fragment(), RestaurantAdapter.OnItemClickListener {
    private val binding by lazy { FragmentHomeBinding.inflate(layoutInflater) }
    private lateinit var user: UserModel
    private lateinit var bottomSheet: BottomSheetDialog
    private lateinit var adapter: RestaurantAdapter
    private lateinit var authViewModel: AuthViewModel
    private lateinit var mainViewModel: MainViewModel
    private lateinit var sliderList: ArrayList<SliderModel>

    private lateinit var database: FirebaseDatabase
    private lateinit var viewPager2: ViewPager2
    private lateinit var pageChangeListener: ViewPager2.OnPageChangeCallback
    private val params = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.WRAP_CONTENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply {
        setMargins(0,0,8,0)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        user = SharedPref.getUserData(requireContext()) ?: UserModel()
        bottomSheet = BottomSheetDialog(requireContext(), R.style.CustomBottomSheetStyle)

        val repository = AuthRepository(FirebaseAuth.getInstance(),  requireContext())
        val factory = AuthViewModelFactory(repository)
        authViewModel = ViewModelProvider(requireActivity(), factory)[AuthViewModel::class.java]

        val mainRepository = MainRepository(requireContext())
        val factory2 = MainViewModelFactory(mainRepository)
        mainViewModel = ViewModelProvider(requireActivity(), factory2)[MainViewModel::class.java]



        viewPager2 = binding.viewPager2
        database = FirebaseDatabase.getInstance()
        pageChangeListener = object : ViewPager2.OnPageChangeCallback(){}

        sliderList = ArrayList()

        mainViewModel.fetchRestaurants()
        fetchSliderData()
        fetchAdminToken()
        if(user.token.isEmpty()) {
            authViewModel.updateToken()
        }
        authViewModel.fetchUserData(user.userId)

        binding.apply {

            btMenu.setOnClickListener {
                showMoreOptions()
            }

            tvName.text = "Hi, ${user.name}"
            adapter = RestaurantAdapter(this@HomeFragment)

            ivProfile.setOnClickListener {
                startActivity(Intent(requireActivity(), ProfileActivity::class.java))
            }

            tvName.setOnClickListener {
                startActivity(Intent(requireActivity(), ProfileActivity::class.java))
            }

            //getting restaurant list
            mainViewModel.restaurantList.observe(viewLifecycleOwner) { list ->
                if(list.isNotEmpty()) {
                    loadingLayout.gone()
                    homeMainLayout.visible()
                    rv.adapter = adapter
                    adapter.submitList(list)
                    search(list)
                } else {
                    loadingLayout.visible()
                    homeMainLayout.gone()
                    tvStatus.text = "No Restaurants Found"
                }

            }

        }

        //managing back press
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true){
            override fun handleOnBackPressed() {
                if(bottomSheet.isShowing) {
                    bottomSheet.dismiss()
                } else {
                    showExitDialog()
                }
            }

        })

    }

    private fun fetchAdminToken() {
        val reference = Firebase.database.getReference(Constants.ADMIN_TOKEN_REF)
        reference.child("tokenId").get().addOnSuccessListener { dataSnapshot ->
            if (dataSnapshot.exists()) {
                val tokenData = dataSnapshot.getValue(AdminTokenModel::class.java)

                tokenData?.let {
                    Constants.ADMIN_TOKEN = tokenData
                    Log.d("mmm", "fetchAdminToken: $tokenData")
                    Log.d("mmm", "fetchAdminToken: ${Constants.ADMIN_TOKEN}")
                }
            } else {
                println("Admin token not found")
            }
        }.addOnFailureListener { exception ->
            println("Failed to fetch admin token: ${exception.message}")
        }
    }

    //fetching slider data
    private fun fetchSliderData() {
        database.getReference(Constants.SLIDER_DOCUMENT).orderByChild("timestamp")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    sliderList.clear()
                    for (childSnapshot in dataSnapshot.children.reversed()) {
                        val sliders = childSnapshot.getValue(SliderModel::class.java)
                        if (sliders != null) {
                            sliderList.add(sliders)
                        }
                    }
                    if (sliderList.isNotEmpty()) {
                        createSlider()
                    } else {
                        binding.card.visibility = View.GONE
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    // Handle onCancelled event if needed
                }
            })
    }

    //creating sliders
    private fun createSlider() {
        val sliderAdapter = SliderAdapter(requireContext())
        val slideDotLL = binding.linearLay
        val viewPager2 = binding.viewPager2

        viewPager2.adapter = sliderAdapter

        val dotImage = Array(sliderList.size) { ImageView(requireContext()) }

        slideDotLL.removeAllViews()

        binding.card.visibility = View.VISIBLE
        dotImage.forEach {
            it.setImageResource(R.drawable.non_active_dot)
            slideDotLL.addView(it, params)
        }

        dotImage[0].setImageResource(R.drawable.active_dot)

        sliderAdapter.submitList(sliderList)

        val pageChangeListener = object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                dotImage.mapIndexed { index, imageView ->
                    imageView.setImageResource(
                        if (position == index) R.drawable.active_dot else R.drawable.non_active_dot
                    )
                }
                super.onPageSelected(position)
            }
        }
        viewPager2.registerOnPageChangeCallback(pageChangeListener)

        val handler = Handler(Looper.getMainLooper())


        val runnable = object : Runnable {
            override fun run() {
                val currentItem = viewPager2.currentItem
                val nextItem = if (currentItem < sliderList.size - 1) currentItem + 1 else 0
                viewPager2.setCurrentItem(nextItem, true)
                handler.postDelayed(this, 3500)
            }
        }
        handler.removeCallbacks(runnable)
        handler.postDelayed(runnable, 3500)
    }

    //show bottom menu
    private fun showMoreOptions() {
        bottomSheet = BottomSheetDialog(requireContext())
        val layout = NavigationLayoutBinding.inflate(layoutInflater)
        bottomSheet.setContentView(layout.root)
        bottomSheet.setCanceledOnTouchOutside(true)

        layout.apply {

            navProfile.setOnClickListener {
                bottomSheet.dismiss()
                startActivity(Intent(requireActivity(), ProfileActivity::class.java))
            }

            navHistory.setOnClickListener {
                bottomSheet.dismiss()
                startActivity(Intent(requireActivity(), OrderHistoryActivity::class.java))
            }

            navCart.setOnClickListener {
                bottomSheet.dismiss()
//                findNavController().navigate(R.id.action_homeFragment_to_cartFragment)
            }

            navPendingOrders.setOnClickListener {
                bottomSheet.dismiss()
//                findNavController().navigate(R.id.action_homeFragment_to_pendingOrdersFragment)
            }

            navShareApp.setOnClickListener {
                bottomSheet.dismiss()
            }

            navAboutUs.setOnClickListener {
                bottomSheet.dismiss()
                startActivity(Intent(requireActivity(), AboutUsActivity::class.java))
            }

            navChatOnWhatsapp.setOnClickListener {
                bottomSheet.dismiss()
                Utils.openWhatsAppChat(requireContext(), "+919876543210")
            }

            navContactUs.setOnClickListener {
                bottomSheet.dismiss()
                Utils.openDialer(requireContext(), "+919876543210")
            }

            navFeedBack.setOnClickListener {
                bottomSheet.dismiss()
                Utils.openEmailClient(requireContext(), "contact@gmail.com")
            }


            navLogout.setOnClickListener {
                bottomSheet.dismiss()
                authViewModel.signOut()
                val intent = Intent(requireActivity(), WelcomeActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                startActivity(intent)
                requireActivity().finish()
            }

            btClose.setOnClickListener {
                bottomSheet.dismiss()
            }

        }


        bottomSheet.show()

    }

    //show existing dialog
    private fun showExitDialog() {
        val bottomSheet = BottomSheetDialog(requireContext())
        val layout = DialogExitBinding.inflate(layoutInflater)
        bottomSheet.setContentView(layout.root)
        bottomSheet.setCanceledOnTouchOutside(true)
        layout.btExit.setOnClickListener {
            bottomSheet.dismiss()
            requireActivity().finishAffinity()
            exitProcess(0)
        }
        layout.btCancel.setOnClickListener {
            bottomSheet.dismiss()
        }
        bottomSheet.show()
    }



    //implementing search feature
    private fun search(list: List<RestaurantModel>) {
        binding.searchView.setOnQueryTextListener(object :
            androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if(list.isNotEmpty()) {
                    filteredList(newText, list)
                }
                return true
            }

        })

    }

    //filtered search
    private fun filteredList(newText: String?, list: List<RestaurantModel>) {
        val filteredList = ArrayList<RestaurantModel>()
        for (category in list) {
            if (category.restaurantName.contains(newText.orEmpty(), ignoreCase = true))
                filteredList.add(category)
        }
        adapter.submitList(filteredList)
        binding.rv.adapter = adapter

    }

    override fun onItemClick(model: RestaurantModel) {
        val intent = Intent(requireActivity(), RestaurantDetailsActivity::class.java)
        intent.putExtra(Constants.RESTAURANT_REF, model)
        startActivity(intent)
    }

}