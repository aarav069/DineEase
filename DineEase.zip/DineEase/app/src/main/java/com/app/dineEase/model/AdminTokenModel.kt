package com.app.dineEase.model

data class AdminTokenModel(
    val tokenId: String = "",
    val token: String = ""
)
