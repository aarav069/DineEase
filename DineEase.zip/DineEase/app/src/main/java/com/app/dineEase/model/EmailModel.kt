package com.app.dineEase.model

data class EmailModel(
    val id: String = "",
    val email: String = ""
)