package com.app.dineEase.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class FoodModel(
    val id: String = "",
    val image: String = "",
    val name: String = "",
    val originalPrice: String = "",
    val offerPrice: String = "",
    val description: String = "",
    val rating: String = ""
): Parcelable
