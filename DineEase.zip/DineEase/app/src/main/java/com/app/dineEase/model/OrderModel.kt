package com.app.dineEase.model

data class OrderModel(
    val id: String = "",
    val userId: String = "",
    val restaurantId: String = "",
    val bookingDate: String = "",
    val bookingTime: String = "",
    val members: String = "",
    val totalAmount: String = "",
    val status: String = "",
    val orderedItems: List<CartModel> = ArrayList(),
    val userToken: String = ""
)