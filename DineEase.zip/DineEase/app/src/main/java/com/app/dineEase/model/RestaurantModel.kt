package com.app.dineEase.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class RestaurantModel(
    val id: String = "",
    val image: String = "",
    val restaurantName: String = "",
    val rating: String = "",
    val reservationCharges: String = "",
    val location: String = ""
): Parcelable
