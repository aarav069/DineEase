package com.app.dineEase.model

data class TimeSlotModel(
    val id: String = "",
    val timeSlot: String = ""
)
