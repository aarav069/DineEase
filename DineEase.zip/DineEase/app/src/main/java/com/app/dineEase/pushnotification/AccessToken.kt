package com.app.dineEase.pushnotification

import com.google.auth.oauth2.GoogleCredentials
import java.io.ByteArrayInputStream
import java.io.IOException
import java.nio.charset.StandardCharsets

object AccessToken {

    private val firebaseMessagingScope = "https://www.googleapis.com/auth/firebase.messaging"

    fun getAccessToken(): String? {
        try {
            val jsonString: String = "{\n" +
                    "  \"type\": \"service_account\",\n" +
                    "  \"project_id\": \"dineease-project-64ac2\",\n" +
                    "  \"private_key_id\": \"06dd70b228cd0b0d612b300ba68de2a7a0731849\",\n" +
                    "  \"private_key\": \"-----BEGIN PRIVATE KEY-----\\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCK4BpMM2+0K4kj\\nwhze8//nOdV7hIgyjZdhDcZgW0gR9Gne6AJC79BX4yrHD8eQpFcsG2N9FheZpHKk\\n9zj+ne7EVFOTosQ3hWLlchnTyQ3g6WjwB4Sn6N2eCWqnBkC8ybFXqL5HivkMFkz3\\ne1kSvuksCUDJgLms8hB6fo2R9TsU0xLM6gj1BgcFF8LcuwZrJpIvMnTnr+ZaO16c\\nQfe470YNut/r60tHDQjb4+gcCcqYfDiaGrgzLgWzkxX5YHkuyLQBJXmxqjDlaoSp\\nlvh1dRBT8G43DcqL9khm7rqJ2yPvvYV2w4FpGrvmmy2vEJrQ17L9SLCO+rxAICtb\\nugi3mHqLAgMBAAECggEABuMKKtE6LuMhz+YmbGAJRrw1fASchHVFFokKV2jvcASA\\n44753bvqxxD65BhCO0gLEqLhEijwTqw7Czc/WlEWsCHGa0HdHSu+NcasxTXpPEgW\\n7iBRUcpYgyfQZCwJNdOCuegiV4Xqx9CrTHKPfkB9a7OhxNxfWNZAPvLbrmtM3MFw\\nLfUIwsGfnnxcnbUYdh9+4ADwAzr1m9woU555FJAANfrJE2SSvUVidGoTDDAFe/ie\\nZ3SMIfmx7OfynByZBOHbM6kWPFHHstR4F3loSPgO+ZMo7GFWKq9qJF2eeHEPPvIT\\nzzS6wsyb/V8wN82xA/ggS9dJ6APm2O2J5rzC0ANWgQKBgQDB0Bp+yJlIRGngp177\\nnwJyKijYokeB4oo2LLiSwNtB45BS0GOgMeddPS4Ew0nzzbMscQVala5H0FSbRgZK\\nJQaaxOpFQJdVuU+N05WUVZoDASI/Aoww/oaMbUoErBc7guqtVlHvdtmtK1JqLXyG\\nTkCKQbZiOD5BS2v9AzXKq4VMIQKBgQC3b2cxVp1lGsrxAvhOmbtw4FiJMhyM4/B5\\nRUDfIyiXx6BOjPw8gLx0z/p1reS6l+Rt/GzU/PsaKGnXK8Yqgq3E/YIa95w6b1xt\\nd4WVuCsWBFc0IAF6W6/x3uF0U1NzN1BXyhHyZZ80EdZsTyxa9N+bG7PhsS2uuH5l\\nJbytNVaRKwKBgQCljkxzrIszLi17F72NFuESAG1vz/9hNdB2QnFP+qnQeMEZ3KSd\\nfMNz5AThUKhlOHsrJUg7fsymz5DWKlTJFSO1JSwxB+G9+lO4hNqrIQw0MM2+IUD7\\nwQ/R+LFXmGEoFsa8VpYbBd0fjXgS9tP+Le33q/ZNpFmZkQGn2QwkGav9wQKBgAJ/\\nJaxqPWIu5yw4miCXvxFePFZBtFnGkHNWGffvhpHqSahICvbX2bjNS99mKoLPpnBI\\ny0Jq3xAQFMC0+9GATdUsjiTH0fyJn3xt8AeFpjB6hqVS+jIsJUzpd7AZoj0jN5i6\\nS1w9Pdl7lKuMuFHUm2aFDgG4Y6LJKA9AYD0LSM5ZAoGBAKENn0v51LwndVduWmPZ\\nQRI40TLdTe5vy92jegMyOZTRLqZ9WZpi23ixxWJkFeqdSwyzLTn/ArOt0FtZXFt3\\nRttlN5F7FVBB5A1Aa7fWwjpUCMle5q0SkT4qzCRatEym/TN4RlLnfhInd91PCbnx\\nmKSHOYitkTMIM/IJiJ/Nx5Xj\\n-----END PRIVATE KEY-----\\n\",\n" +
                    "  \"client_email\": \"firebase-adminsdk-et4eh@dineease-project-64ac2.iam.gserviceaccount.com\",\n" +
                    "  \"client_id\": \"104195411144750604336\",\n" +
                    "  \"auth_uri\": \"https://accounts.google.com/o/oauth2/auth\",\n" +
                    "  \"token_uri\": \"https://oauth2.googleapis.com/token\",\n" +
                    "  \"auth_provider_x509_cert_url\": \"https://www.googleapis.com/oauth2/v1/certs\",\n" +
                    "  \"client_x509_cert_url\": \"https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-et4eh%40dineease-project-64ac2.iam.gserviceaccount.com\",\n" +
                    "  \"universe_domain\": \"googleapis.com\"\n" +
                    "}"

            val stream = ByteArrayInputStream(jsonString.toByteArray(StandardCharsets.UTF_8))
            val googleCredential = GoogleCredentials.fromStream(stream)
                    .createScoped(arrayListOf(firebaseMessagingScope))

            googleCredential.refresh()
            return googleCredential.accessToken.tokenValue
        } catch (e: IOException) {
            return null
        }
    }
}