package com.app.dineEase.pushnotification

data class Notification (
    val message: NotificationData? = null
)