package com.app.dineEase.pushnotification

data class NotificationData(

    val token: String? = null,
    val data: HashMap<String, String>? = null

)