package com.app.dineEase.pushnotification


import com.app.dineEase.pushnotification.AccessToken
import com.app.dineEase.pushnotification.Notification
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST

interface NotificationInterface {


    @POST("/v1/projects/dineease-project-64ac2/messages:send")
    @Headers(
        "Content-Type: application/json",
        "Accept: application/json")
    fun sendNotification(
        @Body message: Notification,
        @Header("Authorization") accessToken: String = "Bearer ${AccessToken.getAccessToken()}"
    ): Call<Notification>


}