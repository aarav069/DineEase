package com.app.dineEase.repository

import android.content.Context
import androidx.lifecycle.MutableLiveData
import com.app.dineEase.model.EmailModel
import com.app.dineEase.model.UserModel
import com.app.dineEase.utils.Constants
import com.app.dineEase.utils.SharedPref
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.tasks.await

class AuthRepository(private val auth: FirebaseAuth, val context: Context) {

    private val fireStore = FirebaseFirestore.getInstance()

    val authStatus: MutableLiveData<Boolean> = MutableLiveData()
    val loginStatus: MutableLiveData<Boolean> = MutableLiveData()
    val forgetPassStatus: MutableLiveData<Boolean> = MutableLiveData()
    val verificationLink: MutableLiveData<Boolean> = MutableLiveData()
    val emailRegistered: MutableLiveData<Boolean> = MutableLiveData()


    //sign up with email
    suspend fun signUpWithEmail(name: String, password: String, phoneNumber: String, email: String, city: String, active: Boolean) {
       try {
           val authResult = auth.createUserWithEmailAndPassword(email, password).await()
           if (authResult.user != null) {
               val userId = authResult.user!!.uid
               registerUser(userId, name, phoneNumber, email, city, active)
           } else {
               authStatus.postValue(false)
           }

       } catch (e: Exception) {
           authStatus.postValue(false)
       }
    }

    //register user to db
    suspend fun registerUser(userId: String, name: String, phoneNumber: String, email: String, city: String, active: Boolean) {
        try {
            val token = FirebaseMessaging.getInstance().token.await()
            val userModel = UserModel(userId, name, phoneNumber, email, city, active, token)
            val userEmail = EmailModel(userId, email)
            fireStore.collection(Constants.EMAIL_REF).document(userId).set(userEmail).await()
            fireStore.collection(Constants.USER_REF).document(userId).set(userModel).await()
            SharedPref.saveUserData(context, userModel)
            authStatus.postValue(true)

        } catch (e: Exception) {
            authStatus.postValue(false)
        }

    }

    //check if email available
    suspend fun isEmailAvailable(email: String) {
        try {
            val query = fireStore.collection(Constants.EMAIL_REF).whereEqualTo("email", email)
            val result = query.get().await()
            emailRegistered.postValue(!result.isEmpty)
        } catch (e: Exception) {
            emailRegistered.postValue(false)
        }

    }

    //fetching user data
    fun fetchUserData(uid: String) {
        fireStore.collection(Constants.USER_REF).document(uid)
            .get()
            .addOnSuccessListener { documentSnapshot ->
                if (documentSnapshot.exists()) {
                    val user = documentSnapshot.toObject(UserModel::class.java)
                    user?.let {
                        //saving user data to offline
                        SharedPref.saveUserData(context, user)
                        loginStatus.postValue(true)
                    }
                } else {
                    loginStatus.postValue(false)
                }
            }
            .addOnFailureListener {
                loginStatus.postValue(false)
            }
    }


//sign up with email and pass
    suspend fun signInWithEmail(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val userId = Firebase.auth.currentUser!!.uid
                    fetchUserData(userId)
                } else {
                    authStatus.postValue(false)
                }
            }.await()

    }

    //sign out
    fun signOut() {
        SharedPref.clearData(context)
        auth.signOut()
    }

    //resending password forget link
    suspend fun sendPasswordResetEmail(email: String) {
        try {
            auth.sendPasswordResetEmail(email)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        forgetPassStatus.postValue(true)
                    } else {
                        forgetPassStatus.postValue(false)
                    }
                }.await()
        }catch (e: Exception) {
            forgetPassStatus.postValue(false)
        }
    }

    //sending verification link
    fun sendVerificationEmail() {
        try {
            auth.currentUser?.sendEmailVerification()
                ?.addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        verificationLink.postValue(true)
                    } else {
                        verificationLink.postValue(false)
                    }
                }
        } catch (e: Exception) {
            verificationLink.postValue(false)
        }
    }

    suspend fun updateToken() {
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
                if (!task.isSuccessful) {
                    return@OnCompleteListener
                }

                val token = task.result
                val userToken = mapOf("token" to token)
                val userId = Firebase.auth.currentUser!!.uid
                fireStore.collection(Constants.USER_REF).document(userId).update(userToken).addOnSuccessListener {
                    loginStatus.postValue(true)

                }
            }).await()

        } catch (e:Exception) {
            loginStatus.postValue(false)
        }
    }

}