package com.app.dineEase.repository

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.app.dineEase.model.CartModel
import com.app.dineEase.model.FoodModel
import com.app.dineEase.model.OrderModel
import com.app.dineEase.model.RestaurantModel
import com.app.dineEase.model.UserModel
import com.app.dineEase.utils.Constants
import com.app.dineEase.utils.SharedPref
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainRepository(context: Context) {
    private val database = FirebaseDatabase.getInstance()
    private val fireStore = FirebaseFirestore.getInstance()

    private val user = SharedPref.getUserData(context) ?: UserModel()
    private val restaurantRef = database.getReference(Constants.RESTAURANT_REF)
    private val restaurantFoodRef = database.getReference(Constants.FOOD_REF)
    private val cartRef = database.getReference(Constants.CART_REF)
    private val orderRef = database.getReference(Constants.ORDERS_REF)
    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    val status: MutableLiveData<Boolean> = MutableLiveData()
    val isInCart: MutableLiveData<Boolean> = MutableLiveData()
    val alreadyInCart: MutableLiveData<Boolean> = MutableLiveData()
    val orderPlaced: MutableLiveData<Boolean> = MutableLiveData()
    val inCartProduct: MutableLiveData<CartModel> = MutableLiveData()

    private val _cartItems: MutableLiveData<List<CartModel>> = MutableLiveData()
    val cartItemsList: LiveData<List<CartModel>> = _cartItems


    private val _restaurantsList = MutableLiveData<List<RestaurantModel>>()
    val restaurantsList: LiveData<List<RestaurantModel>> = _restaurantsList

    private val _restaurant = MutableLiveData<RestaurantModel>()
    val restaurant: LiveData<RestaurantModel> = _restaurant

    private val _restaurantFoodList = MutableLiveData<List<FoodModel>>()
    val restaurantFoodList: LiveData<List<FoodModel>> = _restaurantFoodList

    private val _orderHistory = MutableLiveData<List<OrderModel>>()
    val orderHistory: LiveData<List<OrderModel>> = _orderHistory

    private val _ordersList: MutableLiveData<List<CartModel>> = MutableLiveData()
    val pendingOrdersList: LiveData<List<CartModel>> = _ordersList


    init {
        fetchCartItems(user.userId)
    }


    //fetching restaurants from firebase realtime db
    fun fetchRestaurants() {
        try {
            val models = mutableListOf<RestaurantModel>()
            restaurantRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        models.clear()
                        for (childSnapshot in snapshot.children) {
                            val restaurantModel = childSnapshot.getValue(RestaurantModel::class.java)
                            restaurantModel?.let { models.add(it) }
                        }
                        _restaurantsList.postValue(models)
                    } else {
                        _restaurantsList.postValue(emptyList())
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    status.postValue(false)
                }

            })


        } catch (e: Exception) {
            status.postValue(false)
            println("Error fetching : ${e.message}")
        }
    }

    //fetching restaurant data by id from firebase realtime db
    fun fetchRestaurantById(restaurantId: String) {
        try {
            restaurantRef.child(restaurantId).addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (snapshot.exists()) {
                            val restaurantModel = snapshot.getValue(RestaurantModel::class.java)
                            _restaurant.postValue(restaurantModel ?: RestaurantModel())
                        } else {
                            _restaurant.postValue(RestaurantModel())
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        status.postValue(false)
                        println("Error fetching restaurant: ${error.message}")
                    }
                })

        } catch (e: Exception) {
            status.postValue(false)
            println("Error fetching restaurant: ${e.message}")
        }
    }


    //fetching restaurant food from firebase realtime db
    fun fetchRestaurantFood(id: String) {
        try {
            val models = mutableListOf<FoodModel>()
            restaurantFoodRef.child(id).addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        models.clear()
                        for (childSnapshot in snapshot.children) {
                            val foodModel = childSnapshot.getValue(FoodModel::class.java)
                            foodModel?.let { models.add(it) }
                        }
                        _restaurantFoodList.postValue(models)
                    } else {
                        _restaurantFoodList.postValue(emptyList())
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    status.postValue(false)
                }

            })


        } catch (e: Exception) {
            status.postValue(false)
            println("Error fetching : ${e.message}")
        }
    }


    //fetching user orders
    fun fetchUserOrders(userId: String) {
        try {
            val orderList = mutableListOf<OrderModel>()
            orderRef.child(userId).addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        orderList.clear()
                        for (childSnapshot in snapshot.children) {
                            val order = childSnapshot.getValue(OrderModel::class.java)
                            order?.let { orderList.add(order) }
                        }
                        _orderHistory.postValue(orderList)
                    } else {
                        _orderHistory.postValue(emptyList())
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    _orderHistory.postValue(emptyList())
                }

            })
        } catch (e: Exception) {
            _orderHistory.postValue(emptyList())
        }

    }


    //adding food to cart
    suspend fun addToCart(userId: String, cart: CartModel) {
        try {
            cartRef.child(userId).child(cart.id).setValue(cart)
                .addOnSuccessListener {
                    isInCart(userId, cart.id)
                }.addOnFailureListener {
                    isInCart.postValue(false)
                }.await()

        } catch (e: Exception) {
            isInCart.postValue(false)
        }
    }

    //fetching cart items
    private fun fetchCartItems(userId: String) {
        try {
            val cartList = mutableListOf<CartModel>()
            cartRef.child(userId).addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    cartList.clear()
                    if (snapshot.exists()) {
                        for (childSnapshot in snapshot.children) {
                            val cart = childSnapshot.getValue(CartModel::class.java)
                            cart?.let { cartList.add(it) }
                        }
                    }
                    _cartItems.postValue(cartList)
                }

                override fun onCancelled(error: DatabaseError) {
                    _cartItems.postValue(emptyList())
                }
            })
        } catch (e: Exception) {
            _cartItems.postValue(emptyList())
        }
    }

    //checking food is in cart or not
    private fun isInCart(userId: String, productId: String) {
        cartRef.child(userId).child(productId).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val product = snapshot.getValue(CartModel::class.java) ?: CartModel()
                    inCartProduct.postValue(product)
                    alreadyInCart.postValue(true)
                } else {
                    alreadyInCart.postValue(false)
                }
            }

            override fun onCancelled(error: DatabaseError) {

            }
        })
    }


    //removing food from cart
    suspend fun removeFromCart(userId: String, productId: String) {
        cartRef.child(userId).child(productId).removeValue().await()
    }

//placing order
    suspend fun placeOrder(userId: String, restaurantId: String, date: String,time: String, members: String,status: String, amount: String, foodOrders: List<CartModel>, token: String
    ) {
        try {
            val orderId = orderRef.push().key
            val order = orderId?.let {
                OrderModel(it, userId, restaurantId, date,time, members, amount, status, foodOrders, token)
            }
            if (orderId != null) {
                orderRef.child(userId).child(orderId).setValue(order)
                    .addOnSuccessListener {
                        coroutineScope.launch {
                            clearCart(userId)
                        }
                    }.addOnFailureListener {
                        orderPlaced.postValue(false)
                    }.await()
            }

        } catch (e: Exception) {
            orderPlaced.postValue(false)
            println("Error placing order: ${e.message}")
        }
    }

    //empty the cart after successfully placing order
    private suspend fun clearCart(userId: String) {
        cartRef.child(userId).removeValue().addOnSuccessListener {
            orderPlaced.postValue(true)
        }.await()

    }




}



