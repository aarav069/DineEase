package com.app.dineEase.utils

import com.app.dineEase.model.AdminTokenModel
import com.app.dineEase.model.TimeSlotModel
import java.util.UUID

object Constants {
    const val USER_REF = "Users"
    const val EMAIL_REF = "Emails"
    const val SERVICE_REF = "Services"
    const val CART_REF = "Cart"
    const val ORDERS_REF = "Orders"
    const val USER_IMAGES = "User Images/"
    const val ORDERS_HISTORY_REF = "Orders History"
    const val CATEGORY_REF = "Category"
    const val RESTAURANT_REF = "Restaurants"
    const val ORDERED = "Ordered"
    const val GO_TO_CART = "Go To Cart"
    const val ADD_TO_CART = "Add To Cart"
    const val NOTES_REF = "Notes"
    const val RESTAURANT = "Restaurant"
    const val NOTES = "Notes"
    const val SLIDER_DOCUMENT = "Slider"
    const val FOOD_REF = "Restaurant Foods"
    const val ADMIN_TOKEN_REF = "AdminTokens"
    var ADMIN_TOKEN: AdminTokenModel = AdminTokenModel()

    //manage timeslot here
    val id = UUID.randomUUID().toString()
    val TIME_SLOT_LIST = listOf(
        TimeSlotModel(id, "7:30 AM"),
        TimeSlotModel(id, "8:30 AM"),
        TimeSlotModel(id, "9:30 AM"),
        TimeSlotModel(id, "10:30 AM"),
        TimeSlotModel(id, "11:30 AM"),
        TimeSlotModel(id, "12:30 PM"),
        TimeSlotModel(id, "1:30 PM"),
        TimeSlotModel(id, "2:30 PM"),
        TimeSlotModel(id, "3:30 PM"),
        TimeSlotModel(id, "4:30 PM"),
        TimeSlotModel(id, "5:30 PM"),
        TimeSlotModel(id, "6:30 PM"),
        TimeSlotModel(id, "7:30 PM"),
        TimeSlotModel(id, "8:30 PM"),
        TimeSlotModel(id, "9:30 PM"),
        TimeSlotModel(id, "10:30 PM"),
        TimeSlotModel(id, "11:30 PM"),

    )



}