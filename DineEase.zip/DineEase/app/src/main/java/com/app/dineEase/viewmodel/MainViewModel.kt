package com.app.dineEase.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.app.dineEase.model.CartModel
import com.app.dineEase.model.FoodModel
import com.app.dineEase.model.OrderModel
import com.app.dineEase.model.RestaurantModel
import com.app.dineEase.repository.MainRepository
import kotlinx.coroutines.launch

class MainViewModel(private val mainRepository: MainRepository): ViewModel() {


    val orderPlaced: LiveData<Boolean> = mainRepository.orderPlaced

    val restaurantData: LiveData<RestaurantModel> = mainRepository.restaurant


    val cartItemsList: LiveData<List<CartModel>> = mainRepository.cartItemsList
    val orderHistory: LiveData<List<OrderModel>> =  mainRepository.orderHistory
    val restaurantList: LiveData<List<RestaurantModel>> = mainRepository.restaurantsList
    val restaurantFoodList: LiveData<List<FoodModel>> = mainRepository.restaurantFoodList



    //adding to cart
    fun addToCart(userId: String, cart: CartModel) {
        viewModelScope.launch {
            try {
                mainRepository.addToCart(userId, cart)
            } catch (e: Exception) {
                mainRepository.isInCart.postValue(false)
            }

        }

    }


//removing from cart
    fun removeFromCart(userId: String, productId: String) {
        viewModelScope.launch {
            try {
                mainRepository.removeFromCart(userId, productId)
            } catch (e: Exception) {
                mainRepository.isInCart.postValue(false)
            }

        }
    }



    //fetch restaurant data by id
    fun fetchRestaurantById(restaurantId: String) {
        viewModelScope.launch {
            try {
                mainRepository.fetchRestaurantById(restaurantId)
            } catch (e: Exception) {
                println(e.message)
            }

        }
    }

    //fetching user orders
    fun fetchUserOrders(userId: String) {
        viewModelScope.launch {
            try {
                mainRepository.fetchUserOrders(userId)
            } catch (e: Exception) {
                println(e.message)
            }

        }
    }

    //placing user order
    fun placeOrder(userId: String, restaurantId: String, date: String, time: String, members: String, status: String,  amount: String, foodOrders: List<CartModel>, token: String)  {
        viewModelScope.launch {
            try {
                mainRepository.placeOrder(userId, restaurantId, date, time, members, status, amount, foodOrders, token)
            } catch (e: Exception) {
                mainRepository.orderPlaced.postValue(false)
            }

        }
    }

    //fetching all restaurants
    fun fetchRestaurants() {
        viewModelScope.launch {
            try {
                mainRepository.fetchRestaurants()
            } catch (e: Exception) {
                mainRepository.status.postValue(false)
            }
        }
    }

    //fetching restaurant food
    fun getRestaurantFood(restaurantId: String) {
        viewModelScope.launch {
            try {
                mainRepository.fetchRestaurantFood(restaurantId)
            } catch (e: Exception) {
                mainRepository.status.postValue(false)
            }
        }
    }

}